# ProRider · 26/09b · servidor, Ginásio e app do aluno

Obrigado pelas respostas de 26/09 — ficou tudo claro.

| Arquivo | Versão | Vai para |
|---|---|---|
| `server.js` | 26/09b | Railway (commit novo) |
| `ProRider_1_GINASIO_26-09b.zip` | BUILD 26/09b | executável do Ginásio (não vai para o Railway) |
| `aluno.html` | BUILD 26/09b | Railway: `public/aluno/index.html` |
| `CHANGELOG.md` | até 26/09b | raiz do `prorider-server` |

## 0. Servidor: `server.js` 26/09b

Parte do 24/09a que está publicado. **A mudança principal é na reconexão:**
- `criar_sala` para uma sala que já existe **mantém a sala e os alunos**. Antes, recriava a sala vazia sempre que a conexão do Ginásio caía e voltava, e os celulares ficavam de fora sem perceber.
- Um aluno que entra de novo com o mesmo nome substitui a conexão antiga, e o `close` da antiga não o tira da sala.
- `sala_info` repassa `ocupantes`.

Além disso:
- `aluno_conectou` passa a levar `genero`;
- `/user/login` e `/user/me` devolvem `sexo`.

O banco não muda, porque a coluna `users.sexo` já existe.

**Como confirmar:**
- Com um aluno na aula, derrube a rede do Ginásio por uns segundos. No log do Railway aparece `Sala retomada: … (1 alunos continuam)`, e o celular continua a receber a aula.
- Entre numa sala com uma conta feminina e inicie no Ginásio um desafio Homens × Mulheres. A aluna tem de aparecer na coluna MULHERES.

## 1. App do aluno

Substituir `public/aluno/index.html` pelo `aluno.html` deste pacote e fazer commit junto com o CHANGELOG.
**Como confirmar:** abrir `/aluno`, F12 → Console → filtro `BUILD` → `[ProRider Aluno] BUILD 26/09b`.

O que muda:
- **Nome:** um aluno sem o nome carregado entrava na sala como "–" e aparecia na TV como "-" a 0 W. Agora o app usa o nome da conta ou, sem ele, "Aluno".
- **Desafio:** no fim de um desafio, o celular mostra a colocação do aluno por 10 s.
- **Sexo:** o app manda o sexo da conta ao entrar na sala.
- **Voltar à bike:** depois de reabrir o app, o aluno consegue voltar para a própria bike, que aparece como SUA.
- **Relógio do bloco:** anda mesmo sem bike transmitindo.
- **Vigia:** se a aula parar de chegar por 15 s, o app entra de novo na sala sozinho.

## 2. Executável do Ginásio → 26/09b

Mesmo processo da 25/09a:
1. Copiar o conteúdo do zip para `C:\ProRider\Executavel\app\`, substituindo o que estiver lá.
2. Rodar `npm run dist`.
3. Copiar o `.exe` para `D:\Prodin\Executavel\` e `H:\Executavel\`.

**Como confirmar:** na tela inicial, canto inferior direito, deve aparecer `BUILD 26/09b`. No Console, filtro `BUILD` → `[ProRider] BUILD 26/09b`.

O que muda:
- **Tela de espera:**
  - o perfil da aula não tem mais a linha branca;
  - a coluna da direita não fica mais por cima do perfil.
- **Tela do QR durante a aula (botão Y):** o perfil mostra onde a aula está, com uma agulha que anda e a parte já pedalada escurecida.
- **Gráfico de cartões:**
  - cabe entre os dois círculos laterais;
  - "INÍCIO" e "FIM" só aparecem no começo e no fim da aula.
- **Telas de Potência, Rotação e Ranking:** o mini gráfico do topo acompanha a aula sem os cerca de 5 s de diferença.
- **Desafios:** tela nova nos três modos (Todos × Todos, Homens × Mulheres e Equipes).
  - Não tem rolagem: 10 alunos por coluna; com mais que isso, a lista troca de página a cada 5 s.
  - Nos desafios de grupo, vence a maior média por pessoa.
  - Os desafios passaram a ser equilibrados pelo FTP de cada aluno: gasto calórico em pontos e potência média em % do FTP. A potência máxima continua bruta, em watts.
  - O resultado final mostra um pódio em cada coluna, e há uma barra de progresso sob o nome de cada aluno.
  - Nada corta mais em TV maior que 1920: antes, o relógio e os títulos saíam do lugar.
  - **Cabo de guerra:** desafio novo, com a corda andando pelo esforço de cada lado naquele momento.
  - **Desafio automático no bloco:** no construtor, cada bloco pode ter um desafio com duração em segundos. Na aula, ele começa sozinho e termina no fim do bloco. O `construtor.html` também muda: repare no quadro novo "Desafio automático neste bloco".

## 3. Lembrete

O `PRORIDER.bat` não pode estar aberto enquanto o executável roda: os dois usam a porta 3000.
