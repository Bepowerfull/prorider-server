Oi! Segue o **pacote completo 01/10d**. Ele substitui todos os anteriores. O passo a passo está no `00_LEIA-PRIMEIRO.md`.

**Se você já subiu o 01/10c:** só muda o **Ginásio** (BUILD 01/10d) e o `CHANGELOG.md`. Servidor e site estão iguais.

**O que tem de novo:** tela de espera da TV com o logo original no centro e as aulas de hoje passando embaixo (opção 2 que o Mario aprovou).

**Tem tudo que o Mario aprovou até aqui:**
- telas novas de preparar a aula;
- YouTube de fundo;
- contagem do Spotify;
- e-mails editáveis;
- login de professor em qualquer academia;
- câmera ao vivo;
- **Campeonatos** (Tour, Giro, Vuelta e Mundial);
- logo original em todo lugar (`public/img/logo-prorider.png`).

**Ordem (se for subir tudo):**
1. Servidor e site, no mesmo commit. No log deve aparecer `Migração 01/10a (campeonatos) OK`.
2. Ginásio: BUILD 01/10d. Os arquivos `telas-pv.js` e `logo-prorider.png` precisam estar na pasta antes do `npm run dist`.
3. App: vai junto com o site (`public/aluno/index.html`).

**Nenhuma variável de ambiente nova.**

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar a conta `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` em arquivos ou mensagens.

Qualquer erro no log ou no console da TV, manda print. Obrigado!
