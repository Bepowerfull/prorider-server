Oi! Segue o **pacote completo 01/10b**. Ele substitui todos os anteriores e é a versão para subir tudo de uma vez. O passo a passo está no `00_LEIA-PRIMEIRO.md`.

**Tem tudo que o Mario aprovou:**
- telas novas de preparar a aula;
- YouTube de fundo;
- contagem do Spotify;
- e-mails editáveis;
- login de professor em qualquer academia;
- câmera ao vivo;
- **Campeonatos** (Tour, Giro, Vuelta e Mundial);
- tela de espera nova (símbolo, logo e grade na lateral).

**Ordem:**
1. Servidor e site, no mesmo commit. No log deve aparecer `Migração 01/10a (campeonatos) OK`.
2. Ginásio: BUILD 01/10b. Os arquivos `telas-pv.js` e `logo-prorider.png` precisam estar na pasta antes do `npm run dist`.
3. App: vai junto com o site (`public/aluno/index.html`). Não precisa publicar nada nas lojas.

**Nenhuma variável de ambiente nova.**

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar a conta `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` em arquivos ou mensagens.

Qualquer erro no log ou no console da TV, manda print. Obrigado!
