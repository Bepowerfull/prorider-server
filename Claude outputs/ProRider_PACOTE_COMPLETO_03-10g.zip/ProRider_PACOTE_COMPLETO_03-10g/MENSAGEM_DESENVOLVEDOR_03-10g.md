Oi! Segue o **pacote 03/10g** (vigia: avisos automáticos por e-mail). Ele substitui o 03/10f.

## 1. Subir
- `server.js` e o `index.html` do site (página do admin).
- `5_TESTES_E_BACKUP/testes` para a raiz do repositório (novo: `testes/vigia.test.js`; atualizado: `testes/rodar.js`).
- Ginásio: só mudou o número da versão (BUILD 03/10g). Pode atualizar junto com a próxima mudança de verdade.
- A migração é automática: no log deve aparecer `Migração 03/10e/f/g (segurança, saúde e vigia) OK` (tabela nova `sistema_alertas`).

## 2. Antes do deploy: rodar os testes
```
TEST_DATABASE_URL=postgres://postgres:SENHA@localhost:5432/prorider_teste node testes/rodar.js
```
Agora são 6 grupos (novo: **vigia**). Só suba com **"TUDO OK — pode subir."**

## 3. Variáveis (Railway) — todas opcionais
| Variável | Para quê | Padrão |
|---|---|---|
| `ALERTAS_EMAIL` | Quem recebe os avisos (vários, separados por vírgula) | e-mail do super admin |
| `ALERTAS_INTERVALO_S` | De quanto em quanto tempo o servidor confere | 60 |
| `ALERTA_TV_CAIU_S` | Quanto tempo sem a TV no meio da aula até avisar | 90 |
| `ALERTA_MEMORIA_MB` | Memória do servidor que dispara o aviso | 1536 |

Os avisos saem pelo mesmo e-mail (Resend) das senhas: sem `RESEND_API_KEY` eles ficam só na Saúde do sistema.

## 4. Conferir depois de subir
Admin → **Saúde do sistema** → quadro **Avisos automáticos** → **Mandar e-mail de teste**. Tem que chegar "🧪 ProRider — teste dos avisos".

## O que mudou no `server.js`
- Vigia a cada minuto: TV desligada de 10 min antes a 5 min depois de uma aula da grade (só academias com TV vista nos últimos 14 dias); TV caiu no meio da aula; 10+ erros do servidor em 10 min; 25+ erros das telas em 15 min; webhook do Asaas recusado na última hora; menos de 2 GB para gravações; memória alta; banco fora do ar.
- Tabela `sistema_alertas` (cada aviso uma vez só; os de TV fecham sozinhos quando a TV volta).
- Rotas (admin): `GET /admin/alertas`, `POST /admin/alertas/ligar`, `POST /admin/alertas/rodar`, `POST /admin/alertas/teste`.

Continuam valendo os itens dos pacotes 03/10e e 03/10f.

O pacote passou pela conferência automática e pelos testes (`testes/rodar.js`: TUDO OK num banco vazio).

Obrigado!
