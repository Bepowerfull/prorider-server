Oi! Segue o **pacote 03/10e** (segurança, saúde do sistema, testes automáticos e backup). Ele substitui o 03/10d.

## 1. Subir
- `server.js` e a pasta `2_SITE_pasta_public` inteira (tem 2 arquivos novos: `redefinir.html` e `pr-suporte.js`).
- Copie `5_TESTES_E_BACKUP/testes` e `5_TESTES_E_BACKUP/ferramentas` para a raiz do repositório (ao lado do `server.js`).
- No `.gitignore`, acrescente a linha `backups/` (o repositório é público; cópia do banco nunca vai para o GitHub).

## 2. Antes de cada deploy, de agora em diante: rodar os testes
Precisa de um PostgreSQL local com um banco de teste (o nome tem que ter "test"):
```
createdb prorider_teste
TEST_DATABASE_URL=postgres://postgres:SENHA@localhost:5432/prorider_teste node testes/rodar.js
```
Só suba se terminar com **"TUDO OK — pode subir."** O script apaga e recria esse banco a cada rodada e se recusa a rodar em banco sem "test" no nome. Ele sobe o servidor com variáveis só de teste (nenhuma chave real).

## 3. Backup (Railway)
- No serviço **Postgres** do Railway → aba **Backups**: ligar **Daily**, **Weekly** e **Monthly**.
- Cópia fora do Railway, toda semana (o backup do Railway some se o volume for apagado):
  `DATABASE_PUBLIC_URL='…' ./ferramentas/backup.sh` (gera `backups/prorider_AAAA-MM-DD_HHMM.dump`; guarde também num HD/nuvem).
- **Uma vez agora, provar que volta:** `TEST_DATABASE_URL=… ./ferramentas/restaurar-teste.sh backups/<arquivo>.dump` (restaura no banco de teste e mostra as contagens).

## 4. Volume para as gravações (continua valendo)
Volume montado (ex.: `/data`) e `GRAVACOES_TESTE_DIR=/data/gravacoes`. Sem isso, a página **Saúde do sistema** mostra o alerta.

## 5. Monitor de queda (grátis)
Um monitor (ex.: UptimeRobot) chamando `https://prorider-server-production-5784.up.railway.app/ping` a cada 5 min. Agora o `/ping` responde **503** quando o banco cai. Avisos para o e-mail/WhatsApp do Mario.

## O que mudou no `server.js`
- Tabelas novas (criadas sozinhas): `sistema_eventos`, `senha_reset`, `suporte_relatos`. As tabelas dos grupos de desafio agora nascem na migração certa (antes faltavam num banco novo).
- Limite de tentativas em `/user/login`, `/user/register`, `/display/ativar`, `/user/esqueci-senha`, `/user/redefinir-senha`, `/suporte/relato` (em memória; o IP vem do último valor de `X-Forwarded-For`, o que o proxy do Railway põe).
- `adminAuth` não aceita mais token de modo suporte (`impersonated_by`).
- Rotas novas: `POST /user/esqueci-senha`, `POST /user/redefinir-senha`, `POST /suporte/relato`, `DELETE /user/conta`, `GET /admin/saude`, `POST /admin/saude/relatos/:id/resolver`, `POST /admin/saude/eventos/limpar`.
- `log()` também grava erros e avisos em `sistema_eventos` (30 dias). `unhandledRejection`/`uncaughtException` agora ficam registrados.
- `/ping` → 503 sem banco.

Continuam valendo: Resend com domínio (documento do domínio e e-mail), `ASAAS_WEBHOOK_TOKEN`, não recolocar o seed que trocava senhas.

O pacote passou pela conferência automática e pelos testes (`testes/rodar.js`: pagamento, loja, desafios e segurança — TUDO OK num banco vazio).

Obrigado!
