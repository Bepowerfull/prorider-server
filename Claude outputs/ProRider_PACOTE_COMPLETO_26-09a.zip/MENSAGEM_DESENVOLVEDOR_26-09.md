# ProRider · 26/09 · o que preciso de você

**Este pacote substitui todos os anteriores (23/09b a 25/09a).**

| Arquivo | Versão | Vai para |
|---|---|---|
| `server.js` | licenças por número de bikes | Railway (commit novo) |
| `aluno.html` | BUILD 26/09a | Railway, servido em `/aluno` |
| `CHANGELOG.md` | até 26/09 | raiz do `prorider-server`, no mesmo commit |
| `ProRider_1_GINASIO_25-09a.zip` | BUILD 25/09a | executável do Ginásio e pastas; **não** vai para o Railway |
| `PERGUNTAS_DESENVOLVEDOR_25-09.md` | — | responder e devolver ao Mario |

## 1. Servidor: `server.js` novo

O `server.js` foi feito a partir do que está na pasta `prorider-server` do computador do Mario, com o CHANGELOG até ao `9d4528d`. **Antes de substituir, confira com `git diff` que o arquivo publicado é esse mesmo.** Se houver algo no servidor que não esteja nessa pasta, me avise antes do deploy.

O que muda (detalhes no CHANGELOG, entrada de 24/09):
- a licença passa a mandar no número de bikes: grade da sala, vagas das aulas, reservas e sessões;
- rota nova `GET /display/licenca`; `/display/ativar` e `/display/renovar` devolvem também `max_bikes` e `teto`;
- mínimo de 10 bikes ao criar ou editar uma licença;
- licença demo com 20 bikes, feita no arranque só se ela ainda estiver em 0 ou 15;
- na sala ao vivo, bike acima do número da sala é recusada, e a aula de casa fica limitada ao número de bikes da licença.

Não há tabela nem coluna nova, e nada do banco é apagado.

**Como confirmar depois do deploy:**
- `GET /agenda/grade/PRDR-DEMO-001` → `academia.teto_bikes: 20`, e nenhuma aula com `vagas_max` acima de 20;
- tentar gravar uma licença com 5 bikes no super admin → erro "pelo menos 10 bikes".

## 2. App do aluno

Substituir o `aluno.html` servido em `/aluno`. **Como confirmar:** abrir `/aluno`, F12, e ver `[ProRider Aluno] BUILD 26/09a`.

## 3. CHANGELOG

Substituir o da raiz e fazer o commit junto com os itens 1 e 2.

## 4. Executável do Ginásio → 25/09a

O executável já chegou à 24/09a. Obrigado! Agora é repetir o mesmo processo com o zip novo:
1. Copiar todos os arquivos do zip `ProRider_1_GINASIO_25-09a.zip` para `C:\ProRider\Executavel\app\`. O `bled112.js` é o mesmo.
2. Gerar o executável.

**Como confirmar:** na tela inicial da TV, no canto inferior direito, aparece `BUILD 25/09a`.

**Uma pergunta nova (a 12 do documento):** como o executável abre os vídeos do pendrive? Pelo `http://localhost:3000` ou por `file://`? O corte automático da faixa preta precisa de ler os pixels do vídeo, e com `file://` o navegador pode bloquear essa leitura.

## 4b. Queda do servidor em 25/09 (21:54)

O Railway mandou "Deploy Crashed" para `prorider-server` em produção. Diga o que foi publicado nesse deploy e mande as últimas linhas do *deploy log*. Se foi o `server.js` do pacote, ele foi testado localmente sem banco; com o banco real, o log mostra onde parou.

## 5. 401 na TV

Pelo CHANGELOG, o `JWT_SECRET` fixo foi definido no Railway em 23/09. Isso invalida os tokens emitidos antes, e é por isso que a TV recebe 401. O Mario reativa o Ginásio uma vez (5 toques no logo → código da licença), e fica resolvido enquanto a chave não mudar. **Não trocar a chave de novo.**

## Ordem

1 + 2 + 3 no mesmo deploy → 4 (executável) → Mario reativa o Ginásio → devolver as perguntas respondidas.
