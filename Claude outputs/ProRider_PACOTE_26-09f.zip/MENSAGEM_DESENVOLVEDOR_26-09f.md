# ProRider · 26/09f · só servidor

| Arquivo | Vai para |
|---|---|
| `server.js` | Railway (commit novo, por cima do 26/09e) |
| `CHANGELOG.md` | raiz do `prorider-server`, no mesmo commit |

**O que muda:** a busca de academias do app ("Buscar academia", na Agenda) não achava academia com a cidade preenchida pelo Portal. O Portal grava em `cidade_lic`, e a busca lia só `cidade`. Agora a busca usa as duas, e editar a licença grava as duas.

**Como confirmar:** o Clube Alto dos Pinheiros, com cidade e grade cadastradas, aparece no app em Agenda → Buscar academia.

O Ginásio 26/09e continua valendo; não precisa gerar outro executável por causa disto.
