# ProRider · 23/09 · o que preciso de você

**Anexos deste pacote:**

| Arquivo | Versão | Vai para |
|---|---|---|
| `aluno.html` | BUILD 23/09d | Railway, servido em `/aluno` |
| `CHANGELOG.md` | entradas 23/09b, 23/09c e 23/09d (Ginásio e app) | raiz do `prorider-server` |
| `ProRider_1_GINASIO_23-09d.zip` | BUILD 23/09d | executável do Ginásio (item 4) e pastas; **não** vai para o Railway |
| `PERGUNTAS_DESENVOLVEDOR_23-09.md` | — | responder e devolver ao Mario |

Estes arquivos substituem os anexos da 23/09b.

## 1. URGENTE: o Ginásio está a ser recusado pelo servidor (401)

Na TV, `/display/agenda`, `/display/proxima-aula` e `POST /ginasio/pareamento` respondem **401**. Por isso, em *Minhas Aulas*, o QR do pareamento não aparece e a tela mostra "Sem ligação".

O `server.js` da pasta local já exige `JWT_SECRET` e não tem chave de reserva. Ótimo. Mesmo assim, o `displayAuth` devolve 401 em dois casos diferentes:
- `{"error":"Token inválido"}`: o token foi assinado com outro `JWT_SECRET`. A chave foi trocada, ou o código publicado não é o da pasta local;
- `{"motivo":"outro_computador"}`: a licença foi ativada noutro computador (`licenca_computadores`).

**O que fazer:**
1. Confirmar no Railway que `JWT_SECRET` está definido e dizer se ele foi criado ou trocado depois de 14/09.
2. Confirmar que o commit publicado é o mesmo da pasta local (pergunta 2 do documento).
3. Não trocar a chave nunca mais.
4. Me avisar. Depois disso, o Mario reativa o Ginásio uma vez com o código da licença.

**Como confirmar:** depois da reativação, as três rotas devolvem **200** e o QR de Minhas Aulas aparece. Faça **mais um redeploy** e confirme que continuam 200.

## 2. Publicar o app do aluno 23/09d

- **Pré-requisito:** o Railway tem de estar no commit `1263390` ou mais novo (`prof_remover_aluno`, `prof_trocar_bikes`, `prof_trancar_bike` e `GET /agenda/aula-ativa/:license_id`).
- Substituir o `aluno.html` servido em `/aluno` pelo anexo.
- **Como confirmar:** abrir `/aluno`, F12, e ver `[ProRider Aluno] BUILD 23/09d`.
- Não precisa de nenhuma mudança no `server.js`.

## 3. CHANGELOG

Substituir o `CHANGELOG.md` da raiz do `prorider-server` pelo anexo e fazer o commit junto com o item 2.

## 4. Atualizar o executável do Ginásio para a 23/09d

Na TV, o Console mostra `[ProRider] BUILD 20/09c`: o executável roda os arquivos empacotados nele, e nada do que foi instalado nas pastas desde 20/09 chegou à tela.

**O `bled112.js` já está unificado** a partir do diff que você mandou. O bloco `if (_emElectron) { … } else {` entrou logo depois de `if (BLED112.connected) return;`, e o `} // fim else (Chrome/navegador normal)` fecha o caminho do Chrome depois do bloco do diálogo. No Electron, o comportamento é igual ao do executável atual; no Chrome, é igual ao das pastas. Testei os dois ramos com a porta serial simulada, e cada um segue o seu caminho com as mesmas mensagens de hoje.

**O que fazer:**
1. Copiar **todos** os arquivos do zip `ProRider_1_GINASIO_23-09d.zip`, **incluindo o `bled112.js`**, para `C:\ProRider\Executavel\app\`.
2. Gerar o executável de novo.
3. Testar na academia: as bikes precisam aparecer e ligar como hoje. Se não ligarem, volte o `bled112.js` antigo, me mande o Console e **não** mexa na leitura das bikes.

**Como confirmar:** na TV, F12 → Console → filtro `BUILD` → `[ProRider] BUILD 23/09d`.

## Ordem

1 → Mario reativa o Ginásio → 2 + 3 no mesmo deploy → 4 (executável na 23/09d) → devolver o documento de perguntas respondido.
