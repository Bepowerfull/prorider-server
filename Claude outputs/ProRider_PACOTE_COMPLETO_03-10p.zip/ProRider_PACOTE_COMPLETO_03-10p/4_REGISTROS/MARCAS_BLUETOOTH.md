# ProRider — Bikes, rolos e sensores por Bluetooth (03/10p)

O ProRider lê os **padrões abertos de Bluetooth** (BLE) que quase todas as marcas usam. Por isso não é preciso um código diferente para cada marca: quem segue o padrão funciona.

## Os padrões (os "códigos")

| Padrão | Serviço (UUID) | Dado (UUID) | O que vem | Quem usa |
|---|---|---|---|---|
| **FTMS** — Fitness Machine | `0x1826` | Indoor Bike Data `0x2AD2` | watts, cadência, velocidade, às vezes FC | rolos e bikes inteligentes |
| **Cycling Power** | `0x1818` | Medição `0x2A63` | watts; cadência pelas voltas do pedivela | medidores de potência e muitos rolos |
| **CSC** — velocidade e cadência | `0x1816` | Medição `0x2A5B` | só cadência (sem watts) | sensores de cadência |
| **Frequência cardíaca** | `0x180D` | Medição `0x2A37` | FC | cintas e relógios |
| **Keiser M3i** (próprio) | `0bf669f0-45f2-11e7-9598-0800200c9a66` | anúncio (broadcast) | watts, cadência, marcha, FC | Keiser — **lida pelo dongle da TV; não mudou nada** |

**Ordem que o app usa para ler:** primeiro FTMS (que traz watts e cadência juntos), depois Cycling Power e por último só a cadência.

## Marcas

**Legenda da coluna "Situação":**
- ✅ = segue o padrão; deve funcionar (confirmar no 1º teste com o aparelho).
- 🔎 = depende do modelo; confirmar no teste.
- ❌ = protocolo fechado; não funciona sem adaptador.

### Bikes de academia (spinning)
| Marca / modelo | Padrão | Situação |
|---|---|---|
| Keiser M3i / M3i Total Body | próprio (broadcast) | ✅ já em uso — dongle da TV |
| Schwinn IC4 / IC8 / Bowflex C6 | FTMS (+FC) | ✅ |
| Stages SC2 / SC3 / SB20 | Cycling Power / FTMS | ✅ |
| Wattbike Atom / Pro / Trainer | FTMS + Cycling Power | ✅ |
| Matrix IC7 / CXP | FTMS | 🔎 |
| Life Fitness / ICG IC5–IC7 | Cycling Power | 🔎 |
| Technogym Group Cycle Connect | FTMS | 🔎 |
| Star Trac Spinner (com Bluetooth) | FTMS / Cycling Power | 🔎 |
| Nacionais (Movement, Embreex e outras) | varia; muitas sem Bluetooth | 🔎 — sem Bluetooth, dá para pôr um medidor ou sensor de cadência |
| Peloton | fechado | ❌ |
| Echelon | fechado | ❌ |

### Rolos de treino (em casa)
| Marca / modelo | Padrão | Situação |
|---|---|---|
| Wahoo KICKR, KICKR Core, Snap, Move, KICKR Bike | FTMS + Cycling Power | ✅ |
| Tacx / Garmin Neo, Flux, Flow, Vortex | FTMS + Cycling Power | ✅ |
| Elite Suito, Direto, Zumo, Justo | FTMS + Cycling Power | ✅ |
| Saris H3 / M2 | FTMS + Cycling Power | ✅ |
| Zwift Hub | FTMS + Cycling Power | ✅ |
| JetBlack Victory / Volt | FTMS | ✅ |
| Magene T300 / T600, Thinkrider, Van Rysel D100 / D500 | FTMS + Cycling Power | ✅ |
| Kinetic Road Machine Smart | Cycling Power | ✅ |

### Medidores de potência e sensores
| Tipo | Exemplos | Padrão | Situação |
|---|---|---|---|
| Pedal ou pedivela de potência | Favero Assioma, Garmin Rally/Vector, Stages, 4iiii, Quarq, SRM, Shimano, Magene P505 | Cycling Power | ✅ |
| Sensor de cadência | Wahoo RPM, Garmin, Magene S3+, iGPSPORT | CSC | ✅ (só cadência) |
| Cinta / relógio de FC | Polar, Garmin, Wahoo TICKR, Coospo, iGPSPORT | Frequência cardíaca | ✅ (já em uso) |

## Como funciona em cada lugar

- **Em casa** (pedal livre e aula gravada): o celular do aluno conecta direto no rolo, na bike ou no sensor.
- **Na academia, com Keiser:** nada muda. O dongle da TV lê todas as bikes ao mesmo tempo.
- **Na academia, com outras marcas:** cada aluno conecta a própria bike no celular. O app manda os números (1 vez por segundo) para a TV, que mostra o cartão dele normalmente: watts, cadência, %FTP, zona, calorias e km. Se a bike também for lida pelo dongle (Keiser), **o dongle tem prioridade** e o celular é ignorado. Se o celular parar de mandar, os números do aluno zeram em 4 s.

## Limites
- **iPhone:** o Safari não tem Bluetooth na web. No iPhone é preciso o app **Bluefy** (até termos o app nas lojas).
- **Protocolos fechados:** Peloton e Echelon ficam fora.
- **ANT+:** fica fora; o celular só fala Bluetooth.
- **Resistência:** o rolo ainda não é controlado pelo ProRider (subir a carga sozinho). É o próximo passo possível pelo FTMS (Control Point `0x2AD9`).

## Testado (03/10p)
- Leitura simulada com pacotes reais de cada padrão: FTMS de rolo (velocidade, cadência e potência), FTMS de bike com FC, FTMS com distância e resistência, potência com e sem campos extras, cadência pelo pedivela e contador que dá a volta → todos OK.
- **Correção:** no FTMS, o 1º campo (velocidade) era lido ao contrário. Em vários rolos, a cadência e os watts saíam errados.
- **Correção:** a cadência dos medidores de potência saía de um campo errado (torque).
- **Novo:** os sensores só de cadência (CSC) conectam.
- **Na TV (simulado):** o aluno com a bike no celular aparece com watts, %FTP, zona, kcal e km. Com o dongle lendo, o dongle manda. Quando o celular para, zera.
