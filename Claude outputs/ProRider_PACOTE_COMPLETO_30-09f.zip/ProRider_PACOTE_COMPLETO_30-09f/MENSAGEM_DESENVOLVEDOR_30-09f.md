Oi! Segue o **pacote completo 30/09f**.

**Se você já publicou o 30/09e:**
- troque **só o Ginásio**: `3_GINASIO/ProRider_1_GINASIO_30-09f.zip`, com `npm run dist` como sempre. A tela inicial deve mostrar BUILD 30/09f.
- ponha na raiz do repositório os 3 arquivos da pasta `4_REGISTROS` (`CHANGELOG.md`, `PENDENTES.md` e o novo `CUSTOS_E_PRECOS.md`).

O servidor e o site não mudaram.

**O que muda:** na tela Configurar aula, a câmera ganhou um cartão próprio, "Câmera ao vivo".

**Se ainda está no 30/09d ou antes:** siga o `00_LEIA-PRIMEIRO.md` completo. Os lembretes da 30/09e continuam valendo:
- os arquivos `telas-pv.js` e `logo-prorider.png` precisam ir junto no Ginásio;
- o YouTube pede que a página abra por `http://localhost:3000/ginasio`.
