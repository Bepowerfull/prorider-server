Oi! Segue o **pacote 02/10j**. Ele substitui o 02/10i, e o passo a passo está no `00_LEIA-PRIMEIRO.md`.

**O que subir:**
- `server.js` (uma linha: o `tx_ver` passa `tv:true` para a TV da academia principal);
- no site, `studio.html`;
- o Ginásio inteiro, **com o `servidor-local.js`**, que mudou (cache).

**O que mudou:**
- **Cache no `servidor-local.js`:** rotas `/cache/baixar`, `/cache/status` e `/cache/arquivo` (com Range), só para o próprio computador. Ele baixa as músicas e o vídeo por link (segue os redirecionamentos do Dropbox) para `C:\ProRider\Cache` e apaga o que está sem uso há 2 dias.
- **Aula em rede:**
  - as outras academias recebem a câmera limpa e a voz do professor principal;
  - sem vídeo na aula, o professor vira o fundo; com vídeo, aparece num quadrinho no canto;
  - na academia principal, com vídeo escolhido, a câmera só grava e transmite.
- **Construtor:** vídeo de fundo por link, salvo em `video.link`.
- As rotas do Asaas e a página do financeiro continuam iguais (02/10h/i).

O pacote passou pela conferência automática (`conferir_pacote.py`).

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` nem chaves (Asaas incluída) em arquivos ou mensagens.

Obrigado!
