Oi! Segue o **pacote completo 02/10d**. Ele substitui o 02/10c, e o passo a passo está no `00_LEIA-PRIMEIRO.md`.

**O que mudou desde o 02/10c (só dois arquivos):**
- **`server.js`:** na fase de teste, qualquer login do app vê as aulas gravadas de todas as academias. Para voltar a limitar à academia do aluno: `GRAVADAS_SO_DA_ACADEMIA=1`.
- **`aluno/index.html`:** as caixas de RPM e % FTP da aula gravada ficaram mais justas e nas pontas da tela.

O Ginásio é o mesmo da 02/10c, só com o número BUILD 02/10d: trocar é opcional.

**Se o 02/10c ainda não subiu:** suba este no lugar dele, porque ele já contém tudo.

O pacote passou pela conferência automática (`conferir_pacote.py`).

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` em arquivos ou mensagens;
- a chave do YouTube só o gestor cola no Portal.

Obrigado!
