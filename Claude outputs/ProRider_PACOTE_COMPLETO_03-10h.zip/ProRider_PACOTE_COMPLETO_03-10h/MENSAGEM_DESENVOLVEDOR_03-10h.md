Oi! Segue o **pacote 03/10h** (painel de pós-venda: semáforo das academias, painel por academia, lupinha e código do erro). Ele substitui o 03/10g.

## 1. Subir
- `server.js`.
- Site: `index.html`, `academia.html`, `financeiro.html`, `pr-suporte.js` e `aluno/index.html` (o app).
- `5_TESTES_E_BACKUP/testes` para a raiz do repositório (`telas.test.js` e `vigia.test.js` atualizados).
- **Ginásio:** descompactar `3_GINASIO/ProRider_1_GINASIO_03-10h.zip` em `C:\ProRider\Executavel\app\`, `npm run dist`, conferir **BUILD 03/10h** na tela inicial.
- Nenhuma variável nova. Migração automática (tabela nova `erro_codigos`; coluna `detalhe` em `sistema_alertas`).

## 2. Antes do deploy
```
TEST_DATABASE_URL=postgres://postgres:SENHA@localhost:5432/prorider_teste node testes/rodar.js
```
Só suba com **"TUDO OK — pode subir."**

## O que mudou no `server.js`
- Avisos amarelos não mandam mais e-mail; os vermelhos mandam (chave `alertas_email`, rota `POST /admin/alertas/email`).
- `POST /suporte/erro` aceita `codigo` (ex.: `E-7F3A`) e guarda em `erro_codigos`.
- Rotas novas (admin): `GET /admin/saude/licencas` (semáforo), `GET /admin/saude/licenca/:codigo` (painel da academia com linha do tempo), `GET /admin/saude/busca?q=` (lupinha: E-, S-, A-, R-, academia ou texto).

## Conferir depois de subir
Admin → **Saúde do sistema**: cartões coloridos das academias no topo; clicar abre o painel; a lupinha acha um código E-….

Continuam valendo os itens dos pacotes 03/10e, 03/10f e 03/10g.

O pacote passou pela conferência automática e pelos testes (`testes/rodar.js`: TUDO OK num banco vazio), além dos testes com navegador (TV sem internet, erros do app e do Portal, painel do admin).

Obrigado!
