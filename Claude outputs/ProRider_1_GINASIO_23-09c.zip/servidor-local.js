// Servidor HTTP local para ProRider Ginásio
// Serve os ficheiros estáticos na porta 3000
const http = require('http');
const fs   = require('fs');
const path = require('path');
const os   = require('os');

function getLocalIP() {
  var ifaces = os.networkInterfaces();
  var result = 'localhost';
  Object.keys(ifaces).forEach(function(name) {
    ifaces[name].forEach(function(iface) {
      if (iface.family === 'IPv4' && !iface.internal) result = iface.address;
    });
  });
  return result;
}

const PORT = 3000;
const ROOT = __dirname;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript',
  '.css':  'text/css',
  '.json': 'application/json',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
  '.mp4':  'video/mp4',
  '.mp3':  'audio/mpeg',
  '.woff2':'font/woff2',
  '.woff': 'font/woff',
};

// ── Procura do pendrive ────────────────────────────────────────────
var PASTA_RAIZ = 'ProRider';
var EXT_VIDEO  = ['.mp4', '.webm', '.mkv', '.mov', '.m4v'];
var EXT_AUDIO  = ['.mp3', '.m4a', '.aac', '.wav', '.ogg'];
var _pendriveRaiz = '';           // guardado para validar os pedidos de /midia

function listarUnidades() {
  var out = [];
  if (process.platform === 'win32') {
    for (var i = 67; i <= 90; i++) out.push(String.fromCharCode(i) + ':\\');  // C: ate Z:
  } else {
    ['/media', '/mnt', '/Volumes'].forEach(function(base) {
      try { fs.readdirSync(base).forEach(function(n){ out.push(path.join(base, n)); }); } catch(e) {}
    });
  }
  return out;
}

function juntarArquivos(dir, exts, saida, prof) {
  if ((prof||0) > 2) return;
  var itens = [];
  try { itens = fs.readdirSync(dir, { withFileTypes: true }); } catch(e) { return; }
  itens.forEach(function(it) {
    var cheio = path.join(dir, it.name);
    if (it.isDirectory()) { juntarArquivos(cheio, exts, saida, (prof||0)+1); return; }
    var ext = path.extname(it.name).toLowerCase();
    if (exts.indexOf(ext) >= 0) {
      saida.push({ nome: it.name, caminho: cheio, url: '/midia?p=' + encodeURIComponent(cheio) });
    }
  });
}

function acharPendrive() {
  var unidades = listarUnidades();
  for (var i = 0; i < unidades.length; i++) {
    var raiz = path.join(unidades[i], PASTA_RAIZ);
    var ok = false;
    try { ok = fs.statSync(raiz).isDirectory(); } catch(e) { ok = false; }
    if (!ok) continue;

    var videos = [], musicas = [], aulas = [];
    juntarArquivos(raiz, EXT_VIDEO, videos, 0);
    juntarArquivos(raiz, EXT_AUDIO, musicas, 0);
    try {
      fs.readdirSync(raiz).forEach(function(n) {
        if (/\.prorider$/i.test(n) || /\.json$/i.test(n)) {
          aulas.push({ nome: n, caminho: path.join(raiz, n), url: '/midia?p=' + encodeURIComponent(path.join(raiz, n)) });
        }
      });
    } catch(e) {}

    // So aceita se houver de facto conteudo — evita pegar um C:\ProRider vazio
    if (videos.length || musicas.length || aulas.length) {
      _pendriveRaiz = raiz;
      console.log('  Pendrive encontrado: ' + raiz + '  (' + videos.length + ' video(s), '
                  + musicas.length + ' musica(s), ' + aulas.length + ' aula(s))');
      return { ok: true, raiz: raiz, videos: videos, musicas: musicas, aulas: aulas };
    }
  }
  return { ok: false, raiz: '', videos: [], musicas: [], aulas: [] };
}

function dentroDoPendrive(p) {
  if (!_pendriveRaiz) acharPendrive();
  if (!_pendriveRaiz) return false;
  try {
    var norm = path.resolve(p);
    return norm.toLowerCase().indexOf(path.resolve(_pendriveRaiz).toLowerCase()) === 0;
  } catch(e) { return false; }
}

// Entrega o arquivo aceitando pedidos por trecho (Range). Sem isto o navegador
// nao consegue posicionar o video, e era um dos motivos do
// ERR_REQUEST_RANGE_NOT_SATISFIABLE.
function servirComRange(req, res, arquivo) {
  var st;
  try { st = fs.statSync(arquivo); } catch(e) { res.writeHead(404); res.end('nao encontrado'); return; }
  var tipo = MIME[path.extname(arquivo).toLowerCase()] || 'application/octet-stream';
  var faixa = req.headers.range;

  if (!faixa) {
    res.writeHead(200, { 'Content-Type': tipo, 'Content-Length': st.size, 'Accept-Ranges': 'bytes' });
    fs.createReadStream(arquivo).pipe(res);
    return;
  }
  var m = /bytes=(\d*)-(\d*)/.exec(faixa);
  var ini = m && m[1] ? parseInt(m[1], 10) : 0;
  var fim = m && m[2] ? parseInt(m[2], 10) : st.size - 1;
  if (isNaN(ini) || ini >= st.size) {
    res.writeHead(416, { 'Content-Range': 'bytes */' + st.size }); res.end(); return;
  }
  if (fim >= st.size) fim = st.size - 1;
  res.writeHead(206, {
    'Content-Type': tipo,
    'Content-Range': 'bytes ' + ini + '-' + fim + '/' + st.size,
    'Accept-Ranges': 'bytes',
    'Content-Length': (fim - ini + 1),
  });
  fs.createReadStream(arquivo, { start: ini, end: fim }).pipe(res);
}

http.createServer(function(req, res) {
  var url = req.url.split('?')[0];

  // ── PENDRIVE NATIVO ──────────────────────────────────────────────
  // O navegador nao pode varrer unidades sozinho — exige que o utilizador
  // escolha a pasta, e a autorizacao guardada apodrece quando o pendrive muda
  // (foi a origem dos arquivos de 0 bytes). Aqui, do lado do Node, isso nao
  // existe: procuramos o pendrive direto no Windows.
  // Estrutura esperada:  <unidade>:\ProRider\  com as aulas .prorider e as
  // pastas musica(s) e video(s) dentro.
  if (url === '/pendrive') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' });
    res.end(JSON.stringify(acharPendrive()));
    return;
  }

  // Serve um arquivo do pendrive por endereco FIXO, com suporte a Range —
  // sem Range o navegador nao consegue posicionar o video.
  if (url === '/midia') {
    var alvo = '';
    try { alvo = decodeURIComponent((req.url.split('?')[1]||'').replace(/^p=/, '')); } catch(e) {}
    if (!alvo || !dentroDoPendrive(alvo)) { res.writeHead(403); res.end('fora do pendrive'); return; }
    servirComRange(req, res, alvo);
    return;
  }

  // Endpoint que devolve o IP local para o QR do browser
  if (url === '/localip') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' });
    res.end(JSON.stringify({ ip: getLocalIP(), port: PORT }));
    return;
  }

  if (url === '/' || url === '/ginasio') url = '/ginasio.html';
  var filePath = path.join(ROOT, url);

  fs.readFile(filePath, function(err, data) {
    if (err) {
      res.writeHead(404); res.end('404 Not Found: ' + url);
      return;
    }
    var ext = path.extname(filePath);
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
}).listen(PORT, '0.0.0.0', function() {
  var ip = getLocalIP();
  console.log('');
  console.log('  ProRider GYM — Servidor local a correr');
  console.log('  http://localhost:' + PORT + '/ginasio');
  console.log('  Rede local: http://' + ip + ':' + PORT + '/ginasio');
  console.log('  Aluno (celular): http://' + ip + ':' + PORT + '/aluno');
  console.log('');
  console.log('  Para parar: fechar esta janela');
  try {
    var pd = acharPendrive();
    if (!pd.ok) console.log('  Pendrive: nenhuma pasta ProRider encontrada nas unidades.');
  } catch(e) {}
});
