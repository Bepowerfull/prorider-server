# ProRider · 26/09d · servidor, Ginásio e app

| Arquivo | Versão | Vai para |
|---|---|---|
| `server.js` | 26/09d | Railway (commit novo) |
| `aluno.html` | BUILD 26/09d | Railway: `public/aluno/index.html` |
| `ProRider_1_GINASIO_26-09d.zip` | BUILD 26/09d | executável do Ginásio. Mesmo processo de sempre: copiar para `C:\ProRider\Executavel\app\`, rodar `npm run dist` e copiar o `.exe`. |
| `CHANGELOG.md` | até 26/09d | raiz do `prorider-server`, no mesmo commit |

## Servidor
- **`ftp_resultado`:** caso novo. O Ginásio já mandava o FTP do teste para cada aluno, mas o servidor descartava a mensagem.
- **Fim de aula garantido:** quem entra numa sala cuja aula já foi encerrada recebe o fim na hora. E, sem professor por 3 min, a sala é encerrada **mesmo com alunos dentro**; antes os celulares ficavam presos na aula.
**Como confirmar:** depois de um teste de FTP, o log do Railway mostra `FTP …W enviado para …`.

## App do aluno
- A FC da cinta ligada no celular vai para o Ginásio, e "Avg. HR" passa a ser a média da aula.
- Se a sala não existir mais durante a aula, o app encerra a aula e mostra o resultado.

Ao fim do teste de FTP da aula, o celular mostra o novo FTP durante 1 minuto:
- com atualização automática, grava na hora;
- sem atualização automática, pergunta antes de gravar.

**Como confirmar:** abra `/aluno` e procure no Console a linha `[ProRider Aluno] BUILD 26/09d`.

## Ginásio
- **Fluidez:** as telas passam a ser atualizadas no lugar, sem redesenhar tudo. O anel do teste de FTP anda contínuo.
- **Modo espaço:** segurando LB+RB por 5 segundos, a tela fica escura com estrelas vindo na direção de quem olha.
- **Novo mapa do controle:** RB (toque) = QR Code; Y = frequência cardíaca (tela nova); RT = esconder as caixas; LB+RB segurados 5 s = modo espaço.
- **Tela final e ranking:** no padrão novo, com pódio.
- **Fim de aula:** se não houver conexão no encerramento, o aviso sai quando a conexão voltar. Fechar o programa também avisa os celulares.
- **Teste de FTP:** só participa quem pedalou nos 10 primeiros segundos.
- **Tela do QR:** a lista de alunos não tem mais rolagem.
- **Ranking:** acima de 20 alunos, alterna entre grupos a cada 10 segundos.

**Como confirmar:** na tela inicial deve aparecer `BUILD 26/09d`.
