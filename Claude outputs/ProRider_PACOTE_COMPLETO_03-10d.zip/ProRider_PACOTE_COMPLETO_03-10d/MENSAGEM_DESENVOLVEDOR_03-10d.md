Oi! Segue o **pacote 03/10d**. Ele substitui o 03/10c.

**Se o 03/10c já está no ar, basta trocar o `public/index.html`** (painel do admin: botão "Nova senha" e página de pagamentos). O `server.js` é o mesmo do 03/10c. O resto abaixo continua valendo.

**Na dúvida, suba tudo deste pacote:** `server.js`, a pasta `2_SITE_pasta_public` inteira e o Ginásio inteiro.

**O que depende de você no Railway:**

1. **Volume para as gravações (importante).** A TV envia as aulas gravadas para a pasta `GRAVACOES_TESTE_DIR` do servidor. Sem Volume, **cada deploy apaga esses vídeos** — por isso aula gravada some do app depois de subir uma versão nova. Crie um Volume (ex.: montado em `/data`) e ponha `GRAVACOES_TESTE_DIR=/data/gravacoes`.
2. **Continua valendo do 03/10b:** apagar o seed que volta a senha das Demo para `12345678`; Resend com domínio verificado + `EMAIL_FROM`; `ASAAS_WEBHOOK_TOKEN`.
3. **Asaas:** a venda de aulas usa a mesma `ASAAS_API_KEY` e o mesmo webhook (pedidos com `externalReference` = `loja:<id>`). Nada novo para configurar.

**O que mudou no `server.js`:**
- Migração automática: tabelas `sistema_cfg`, `loja_professores`, `loja_aulas`, `loja_produtos`, `loja_pedidos`, `loja_desbloqueios`, `desafio_conquistas`, `ftp_historico` (+ gatilho `pr_ftp_hist` em `users.ftp`); coluna `users.asaas_customer`; FKs de `desafio_grupos`/`desafio_grupo_membros` com `ON DELETE` (apagar conta não trava mais).
- Rotas novas: `GET /loja`, `POST /loja/comprar`, `GET /loja/pedidos/:id`, `POST /loja/aulas/:id/usar-credito`, `GET/PUT/POST/DELETE /admin/loja*`, `GET /admin/loja/repasse`, `POST /admin/loja/cortesia`, `GET /desafios/meus`, `POST /desafios/grupos/:codigo/sair`.
- Rankings de desafio reais (`mensal`, `21dias`, `ftp`); ranking do grupo segue o desafio do grupo.
- Webhook do Asaas: pedidos `loja:` vão para a loja antes da parte das licenças.
- Aula gravada da loja: acesso pela compra/crédito/assinatura; vídeo pode ser um link (redireciona).
- O CPF do comprador vai direto ao Asaas; não é gravado no nosso banco.

Testado com o Asaas simulado e no navegador (compra com PIX simulado, crédito, assinatura, estorno, desafios, gravação até o app). O pacote passou pela conferência automática (`conferir_pacote.py`).

Obrigado!
