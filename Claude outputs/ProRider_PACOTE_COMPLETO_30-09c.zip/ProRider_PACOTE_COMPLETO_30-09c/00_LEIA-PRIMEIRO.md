# ProRider — Pacote completo 30/09c

Este pacote traz **tudo o que o Mario aprovou até 30/09**, pronto para publicar. Ele substitui todos os pacotes anteriores (29/09a, 29/09b, 29/09c, completo 29/09c, 30/09a e 30/09b): **use só este**.

> **Já publicou um pacote completo anterior (29/09c, 30/09a ou 30/09b)?** Então só faltam:
> - **dois arquivos do site:** `public/studio.html` e `public/academia.html` (pasta `2_SITE_pasta_public`);
> - **o Ginásio** `3_GINASIO/ProRider_1_GINASIO_30-09b.zip` (passo 3), se ainda não foi instalado;
> - **o `CHANGELOG.md` e o `PENDENTES.md`.**
>
> O servidor e o app são os mesmos do 29/09c.

**Novo no 30/09c (só site):** o **Construtor de aulas online** (`studio.html`) foi refeito com o visual do Portal. A aula inteira aparece num gráfico só, sem passar da tela; a música fica no mesmo tempo do gráfico; e a aula pode ser salva na conta, para aparecer no Ginásio em Minhas aulas. No Portal, a aba "Criar aula" virou "Construtor de aulas", e o **professor passa a entrar no Portal** (vê só o Construtor e o perfil).

**Novo no 30/09a/30/09b (só Ginásio):**
- o gráfico da aula fica cerca de 25% maior e volta ao tamanho do projeto em qualquer TV (antes encolhia em TV ou notebook com a escala do Windows em 125% ou 150%);
- a tela de imersão (LB+RB 5 s) passa a cobrir a TV inteira (antes ficava num canto);
- regra do SELECT: no teste de FTP e no desafio, o 1º SELECT para e mostra o resultado, e o 2º volta ao gráfico principal. Na imersão, o SELECT sai. Sem nada rodando, o SELECT pergunta se quer encerrar a aula.

Resumo do que entra:

- **Site/Portal:** entrada nova "Ride With Purpose", idêntica à arte, com contadores ao vivo. Páginas novas "Totem na porta", "Página no site" (com o código para a academia colar no site dela) e "Localização no app".
- **App do aluno:**
  - faixa verde "aula ao vivo" para entrar pela lupinha;
  - busca **"Perto de mim"** pelo GPS do celular, com a distância até cada academia;
  - brasões novos;
  - aulas de hoje corrigidas na grade.
- **Ginásio (TV):** cartões grandes das aulas do dia na tela de espera, brasão ao lado do nome no ranking, gráfico no tamanho certo em qualquer TV, imersão em tela cheia e a regra do SELECT.
- **Novidades para as academias:**
  - **Totem:** um tablet na porta da sala para reservar, se cadastrar e entrar na aula sem celular.
  - **Página pública:** uma página com números, grade e ranking que a academia coloca no site dela.
  - **Brasões:** 20 degraus, começando em Aquecimento, Cadência e Pelotão, antes do Bronze.

---

## 1. O que tem em cada pasta

| Pasta | O que é | Para onde vai |
|---|---|---|
| `1_SERVIDOR/server.js` | Servidor 29/09c (já contém os seus 26/09g e 26/09h) | Raiz do repositório `prorider-server` (Railway) |
| `2_SITE_pasta_public/` | Portal, site, totem, página pública e o app do aluno | Pasta `public/` do `prorider-server`, **com a mesma estrutura** |
| `3_GINASIO/ProRider_1_GINASIO_30-09b.zip` | Programa da TV (BUILD 30/09b) | Computador do Ginásio: `C:\ProRider\Executavel\app\` |
| `4_REGISTROS/` | `CHANGELOG.md` e `PENDENTES.md` | Raiz do `prorider-server` (substituir) |

Detalhe da pasta `2_SITE_pasta_public/`:

```
public/
├── index.html              entrada do site + Portal do super admin
├── academia.html           Portal da academia (gestor)
├── aluno.html              portal do aluno (navegador)
├── aluno/index.html        APP DO ALUNO (BUILD 29/09c)  ← atenção: fica na subpasta aluno/
├── brasoes.js              NOVO: desenho dos brasões (usado por várias páginas)
├── academia-publica.html   NOVO: página pública da academia
├── totem.html              NOVO: totem do tablet da porta
├── img/                    NOVA PASTA: 4 imagens da tela de entrada
│   ├── entrada-arte.jpg
│   ├── entrada-logo.jpg
│   ├── entrada-titulo.jpg
│   └── entrada-ciclista.jpg
└── jim.html, onboarding.html, studio.html   (iguais aos de hoje, só para a pasta ficar completa)
```

**Copie por cima e substitua os de mesmo nome.** Não apague outros arquivos que já existam em `public/`.

---

## 2. Antes de começar (2 minutos)

1. **Faça uma cópia de segurança** do que está no ar hoje: `server.js` e a pasta `public/` inteira, ou só anote o commit atual no GitHub. Se algo der errado, é só voltar.
2. **Se você mudou o `server.js` no GitHub depois do 26/09h**, me avise antes de substituir. Este arquivo tem o seu 26/09g (o `/ping` sem `db_url`) e o 26/09h (rotas de setup com `SETUP_KEY`). Mudanças posteriores precisam ser juntadas à mão.

---

## 3. Ordem de publicação

### Passo 1: servidor (primeiro, porque as páginas usam rotas novas)
1. Troque `server.js` na raiz do `prorider-server`.
2. Troque `CHANGELOG.md` e `PENDENTES.md` (pasta `4_REGISTROS`).
3. Commit e push. O Railway publica sozinho.
4. **Confira no log do Railway** (aba Deployments → View logs). Devem aparecer:
   - `Migração 29/09a (brasões, página pública, totem) OK`
   - `Migração 29/09c (localização) OK`
   - uns 15 segundos depois, linhas `geo: CODIGO → lat,lng`, uma para cada academia que já tem endereço cadastrado.

   Se aparecer `Migração ERRO`, **pare** e me mande o log.

### Passo 2: site, Portal e app (no mesmo commit do passo 1, se preferir)
1. Copie o conteúdo de `2_SITE_pasta_public/` para `public/`, **incluindo a pasta nova `img/`** e o arquivo `aluno/index.html`.
2. Commit e push.

### Passo 3: Ginásio (computador da TV)
1. Descompacte `3_GINASIO/ProRider_1_GINASIO_30-09b.zip` em `C:\ProRider\Executavel\app\`, substituindo os arquivos. Tem um arquivo novo: `brasoes.js`.
2. Rode `npm run dist`, como nas outras versões.
3. Abra o programa: a tela inicial mostra **BUILD 30/09b**.

---

## 4. Variáveis de ambiente (Railway)

**Nenhuma variável nova é obrigatória.**

| Variável | Precisa? | Para quê |
|---|---|---|
| `SETUP_KEY` | Só se for usar as rotas de setup | Com 12 caracteres ou mais. Sem ela, `/admin/criar-admin`, `/admin/setup-promote`, `/setup/bootstrap` e `/setup/sessao-teste` respondem 404 (é o comportamento seguro). |
| `GEOCODER_EMAIL` | Opcional | Contato enviado ao serviço de mapa (OpenStreetMap). Padrão: contato@prorider.app. |

A busca de endereço no mapa usa o **OpenStreetMap (Nominatim)**, que é grátis e não tem chave. O servidor só precisa acessar `https://nominatim.openstreetmap.org`, e o Railway já acessa a internet normalmente.

---

## 5. Banco de dados

**Não precisa rodar nada à mão.** O servidor faz tudo sozinho ao iniciar, e é seguro rodar mais de uma vez:

- colunas novas em `licencas`: `pagina_cfg`, `totem_token`, `geo_fonte` e `geo_em`. As colunas `lat` e `lng` já existiam e agora são usadas;
- recalcula `users.level` pela escada nova de brasões, pelos pontos que cada aluno já tem. **Ninguém perde pontos.**

---

## 6. Como conferir que subiu certo (5 minutos)

| # | Onde | O que deve acontecer |
|---|---|---|
| 1 | Abrir a raiz do servidor no navegador do computador | A tela "RIDE WITH PURPOSE" aparece com os 6 contadores preenchidos |
| 2 | A mesma raiz no celular | Versão empilhada (logo, título, login, contadores) |
| 3 | `GET /public/stats` | JSON com `atletas`, `km`, `kcal`, `aulas`, `horas`, `wpp_total` |
| 4 | `GET /agenda/cidades?lat=-23.56&lng=-46.70` | Lista de academias com `dist_km`, em ordem de distância |
| 5 | Portal → entrar numa academia → **Página no site** | Cartões "Localização no app" e "Link e código para o site", com a prévia à direita |
| 6 | Portal → **Totem na porta** | Link e QR do totem |
| 7 | App (`/aluno`) → Agenda | Botão **"Perto de mim"** abaixo da busca |
| 7b | Portal → **Construtor de aulas** → Abrir o Construtor | Construtor novo com o visual do Portal; blocos cabem na tela; "Salvar na minha conta" funciona |
| 8 | Ginásio | BUILD 30/09b na tela inicial; com aula na grade de hoje, a tela de espera mostra os cartões grandes |
| 9 | Ginásio, na aula | LB+RB segurados 5 s escurecem a **TV inteira**; SELECT volta ao gráfico |
| 10 | Ginásio, na aula | Teste de FTP ou desafio: SELECT para e mostra o resultado; SELECT de novo volta ao gráfico. Sem nada rodando: SELECT pergunta "Encerrar aula?" |

---

## 7. Teste do Mario: reserva e entrada pela lupinha

Depois de publicado, o Mario faz este roteiro no Clube:

1. **Localização:** pelo **celular, dentro do Clube**, abrir o Portal → Página no site → **"Estou na academia: usar este aparelho"** → permitir. O cartão fica verde: "✓ Aparece no Perto de mim".
2. **Grade:** Portal → Grade → confirmar que tem aula hoje; se não tiver, criar uma para daqui a uns 30 minutos.
3. **Reserva:** no app, Agenda → **Perto de mim** → Clube → reservar a aula de hoje. Ela aparece em "Minhas reservas".
4. **Abrir a aula:** no Ginásio, abrir a aula (pré-aula, tela do QR).
5. **Entrar pela lupinha:** em até 15 segundos, o Clube aparece no app com a etiqueta verde "AULA ABRINDO · N bikes livres". Tocar no Clube → faixa verde "aula ao vivo" → escolher a bike. **O nome aparece na TV.**

Se algum passo falhar, anote em qual e mande o print para o Mario me repassar.

---

## 8. Se precisar voltar atrás

- **Servidor e site:** volte ao commit anterior no GitHub, e o Railway republica. As colunas novas do banco não atrapalham a versão antiga, porque só são lidas pelo código novo.
- **Ginásio:** reinstale o executável anterior.

---

## 9. Segurança (lembretes que continuam valendo)

- Trocar a senha do Postgres no Railway, se ainda não trocou.
- Trocar a senha do super admin, se ainda for a antiga.
- Trocar a senha de `gestor001@prorider.com` ou desativar essa conta: a senha dela está escrita na migração antiga.
- **Nunca** colocar `DATABASE_URL` ou senhas em arquivos, commits ou mensagens.

---

Detalhes técnicos de cada mudança (o que mudou, por quê, como confirmar, cuidados) estão no `CHANGELOG.md`, nas entradas **30/09c**, **30/09b**, **30/09a**, **29/09c** e **29/09b**.
