Oi! Segue o **pacote 02/10i**, um ajuste pequeno no Portal. Ele substitui o 02/10h.

**O que subir:** no site, `academia.html` e `financeiro.html`. O `server.js` não mudou desde o 02/10h, e o Ginásio só mudou o número da versão.

**O que mudou:**
- O financeiro entra pela mesma tela de entrada do Portal. Lá tem "Primeiro acesso? Criar conta", com o mesmo cadastro do app (sem os dados de pedalar).
- Se o e-mail é o financeiro da licença, a pessoa cai direto no pagamento.
- O `financeiro.html` não tem mais tela de login própria: sem login, ele volta para a entrada do Portal.

**Se o 02/10h ainda não subiu:** suba este no lugar dele, com o `server.js`. Os cuidados do 02/10h (teste no sandbox do Asaas antes da 1ª cobrança real) continuam valendo.

O pacote passou pela conferência automática (`conferir_pacote.py`).

Obrigado!
