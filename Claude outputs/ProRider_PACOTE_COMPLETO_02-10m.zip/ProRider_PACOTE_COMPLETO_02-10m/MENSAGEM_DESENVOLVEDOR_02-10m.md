Oi! Segue o **pacote 02/10m**. Ele substitui o 02/10l.

**Na dúvida sobre o que já subiu, suba tudo deste pacote:** o `server.js`, a pasta `2_SITE_pasta_public` inteira e o Ginásio inteiro, com o `servidor-local.js`.

**O que mudou desde o 02/10l:**
- **`server.js`:** coluna `users.senha_provisoria` (criada sozinha). Ela fica marcada nas contas criadas pelo admin com senha provisória e é zerada em `PUT /user/senha`. O login devolve esse campo.
- **`financeiro.html`:** menu próprio, com Pagamento, Meus dados (nome e troca de senha) e Sair, e o aviso "Crie a sua senha" enquanto a senha for a provisória.
- **Continua valendo do 02/10l:** na subida, as licenças sem situação viram `ativa`, o que destrava as TVs das Demo.

O pacote passou pela conferência automática (`conferir_pacote.py`).

Obrigado!
