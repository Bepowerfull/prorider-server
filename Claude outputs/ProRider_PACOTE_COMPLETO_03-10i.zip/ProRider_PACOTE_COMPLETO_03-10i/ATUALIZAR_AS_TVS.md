# Atualizar o Ginásio nas TVs (Demo 01 e Clube) — BUILD 03/10i

As duas TVs estão em versões antigas: **Demo 01 = BUILD 02/10j** e **Clube = BUILD 01/10d**.
Sem a versão nova, a TV não guarda a aula quando a internet cai, não manda os erros para a Saúde do sistema e não mostra o código do erro (E-XXXX).

## Parte 1 — gerar o programa novo (uma vez só, no computador onde fica `C:\ProRider\Executavel`)

1. Feche o ProRider, se estiver aberto.
2. Descompacte `3_GINASIO/ProRider_1_GINASIO_03-10i.zip` dentro de **`C:\ProRider\Executavel\app\`** e escolha **substituir** os arquivos.
3. Abra o **Prompt de Comando** nessa pasta (`C:\ProRider\Executavel`) e rode: `npm run dist`
4. Quando terminar, o programa novo fica em **`C:\ProRider\Executavel\dist\`** (o arquivo `.exe`).

## Parte 2 — instalar em cada TV (Demo 01 e Clube)

1. Copie o `.exe` novo para o computador da TV (pendrive, OneDrive ou rede) e coloque **no mesmo lugar** do programa antigo, substituindo-o.
2. Abra o ProRider.
3. Confira, na tela inicial (canto de baixo, à direita): **BUILD 03/10i**.
4. A ativação da licença continua (não pede o código de novo). Se pedir, use o código da licença dessa academia (Portal → Licenças).
5. Abra **uma aula de teste** até a tela do QR e feche — isso faz a TV aparecer como online na Saúde do sistema.

## Parte 3 — conferir no admin

Admin → **Saúde do sistema** → tabela **TVs (Ginásio)**: as duas devem mostrar **BUILD 03/10i** e "● online" (enquanto o programa estiver aberto).

## Se algo der errado

- Volte a usar o `.exe` antigo (guarde uma cópia antes de substituir).
- Tire foto da tela e mande para o Mario/Claude. Se aparecer um código **E-XXXX** pequeno no canto da TV, anote: ele acha o erro na lupinha da Saúde do sistema.
