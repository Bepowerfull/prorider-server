Oi! Segue o **pacote completo 02/10b**. Ele substitui o 02/10a, e o passo a passo está no `00_LEIA-PRIMEIRO.md`.

**O que mudou desde o 02/10a:**
- **Aula gravada no app (fase de teste):**
  - "Gravar" na TV grava a câmera limpa e um roteiro da aula;
  - depois da aula, a TV manda o vídeo para o servidor em pedaços de 8 MB;
  - o app toca o vídeo em Loja → Aulas gravadas, com os números do próprio aluno;
  - ficam até 5 por academia, apagadas em 72 h, numa pasta temporária do servidor. Um redeploy apaga as de teste, e isso é esperado.
- **Saiu a mensalidade da academia:** sem planos e assinaturas. As tabelas não são mais criadas. Se o 02/10a já tiver criado `planos` e `assinaturas` no banco, podem ficar, porque nada mais usa.
- **`servidor-local.js` mudou de novo:** troque junto com o Ginásio.

**Variável opcional:** `GRAVACOES_TESTE_DIR` (pasta das gravações de teste no servidor). Se o Railway tiver um volume, aponte para ele; sem ela, o servidor usa a pasta temporária.

**Atenção à banda:** cada gravação de teste sobe uns 0,6 GB pela internet da academia, em segundo plano, depois da aula.

O pacote passou pela conferência automática (`conferir_pacote.py`).

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` em arquivos ou mensagens;
- a chave do YouTube só o gestor cola no Portal.

Obrigado!
