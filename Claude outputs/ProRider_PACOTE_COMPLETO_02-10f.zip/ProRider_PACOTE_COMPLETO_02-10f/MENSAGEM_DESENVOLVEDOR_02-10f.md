Oi! Segue o **pacote completo 02/10f**. Ele substitui o 02/10e, e o passo a passo está no `00_LEIA-PRIMEIRO.md`.

**O que mudou desde o 02/10e:**
- **Construtor (`studio.html`):** música por link (Dropbox ou Google Drive), salva em `musica.trilha[i].link`.
- **Ginásio (BUILD 02/10f):** toca pelo link e usa o pendrive como reserva; aula em rede com horário para o START, as outras seguindo sozinhas se a mãe não começar, e "Recomeçar" nos primeiros 5 min.
- **`server.js`:** contador de reinício na aula em rede e a mensagem `aula_reiniciada` para os celulares.
- **`aluno/index.html`:** zera os números da largada quando a aula é recomeçada.
- `servidor-local.js` **não mudou**.

**Se o 02/10e ainda não subiu:** suba este no lugar dele, porque ele já contém tudo.

O pacote passou pela conferência automática (`conferir_pacote.py`).

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` em arquivos ou mensagens;
- a chave do YouTube só o gestor cola no Portal.

Obrigado!
