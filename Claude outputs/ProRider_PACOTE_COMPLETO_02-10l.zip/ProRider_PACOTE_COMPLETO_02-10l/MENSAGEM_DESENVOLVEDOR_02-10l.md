Oi! Segue o **pacote 02/10l**. Ele substitui o 02/10k.

**Achei a causa do "Licença não encontrada ou inativa":** as licenças ProRider Demo 01 e Demo 02 estão com `status` NULL. É o "null" que aparece ao lado do código na lista do admin. O `/display/ativar` só aceita `status='ativa'`.

**O que subir:** `server.js` e, no site, `index.html`. O Ginásio não mudou.

**O que mudou:**
- **Na subida, o servidor corrige sozinho:** `UPDATE licencas SET status='ativa' WHERE status IS NULL OR status='trial'`. O padrão da coluna passa a ser `ativa`, e a edição de licença nunca mais grava situação vazia (o plano Trial mandava `trial`, que também travava a TV).
- **Editar/Nova licença no admin:** ganhou as seções **Gestor** e **Financeiro**, cada uma com nome e e-mail.
  - Conta que já existe vira gestor ou financeiro da licença.
  - E-mail sem conta: a conta é criada com senha provisória, que aparece para o admin e vai no e-mail de boas-vindas.
  - Trocar um e-mail tira o acesso do anterior.

**Se precisar destravar antes do deploy:**
`UPDATE licencas SET status='ativa' WHERE status IS NULL;`

O pacote passou pela conferência automática (`conferir_pacote.py`).

Obrigado!
