Oi! Segue o **pacote completo 01/10a** (substitui todos). O passo a passo está no `00_LEIA-PRIMEIRO.md`.

**O que muda:** Campeonatos (Tour, Giro, Vuelta e Mundial).
- **Servidor:**
  - 4 tabelas novas (`campeonatos`, `campeonato_etapas`, `campeonato_resultados`, `camisas_conquistadas`), que o servidor cria sozinho;
  - rotas novas em `/gestor/campeonatos*`, `/display/campeonato/*`, `/campeonato/:id/classificacao` e `/user/campeonatos|camisas`.
  - No log deve aparecer `Migração 01/10a (campeonatos) OK`.
- **Site:** `academia.html` (menu Campeonatos) e `aluno/index.html` (app).
- **Ginásio:** BUILD 01/10a. O zip tem `telas-pv.js` e `logo-prorider.png`, que precisam ir junto antes do `npm run dist`.

**Ordem:** servidor + site (mesmo commit) → Ginásio.

**Nenhuma variável de ambiente nova.**

**Para testar:**
1. Portal → Campeonatos → marcar uma aula de hoje → Salvar.
2. Abrir a aula no Ginásio no horário: aparece "Etapa 1 de N".
3. Fim da aula → B → qualquer botão: aparece a classificação do campeonato.

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar a conta `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` em arquivos ou mensagens.
