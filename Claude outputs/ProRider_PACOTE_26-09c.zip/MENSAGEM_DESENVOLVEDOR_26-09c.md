# ProRider · 26/09c · só o Ginásio

Esta versão muda só o Ginásio. Servidor e app continuam na 26/09b.

| Arquivo | Vai para |
|---|---|
| `ProRider_1_GINASIO_26-09c.zip` | executável do Ginásio (mesmo processo: copiar para `C:\ProRider\Executavel\app\` → `npm run dist` → copiar o `.exe`) |
| `CHANGELOG.md` | raiz do `prorider-server` (commit, sem deploy) |

**O que muda:**
- **Ranking:** com muitos alunos (20 ou mais), não corta mais nomes, números nem posições.
- **Resultado do desafio:** os números param no valor do fim e não mudam mais com a turma pedalando.
- **Desafio ao vivo:** mais fluido. O relógio e os números andam de forma contínua, e barras e corda deslizam.
- **Gráfico antigo desativado:** fica só o gráfico de cartões. O RT esconde as caixas, e o gráfico desce e cresce 30%.
- **Trocas de tela:** passam a esmaecer rapidamente em vez de trocar de uma vez.
- **Teste de FTP:** tela nova, ao vivo e no resultado. O FTP passa a ser calculado pela média do teste, como no app do aluno; antes, o Ginásio usava o último instante e inflava o valor.

**Como confirmar:** na tela inicial, canto inferior direito, deve aparecer `BUILD 26/09c`.
