# ProRider — Pacote completo 02/10c

Este pacote traz **tudo o que o Mario aprovou até 02/10 (c)** e substitui todos os anteriores: **use só este**.

> **Já publicou o 02/10b?** Então troque:
> - no site, **`studio.html`** (Construtor);
> - o **Ginásio** inteiro (`3_GINASIO/ProRider_1_GINASIO_02-10c.zip`);
> - os registros.
>
> O `server.js` e o `servidor-local.js` não mudaram desde o 02/10b.
>
> **Ainda está no 02/10a ou antes?** Suba tudo deste pacote: servidor, a pasta `public/` inteira e o Ginásio (com o `servidor-local.js`).

## Novo no 02/10c

- **Construtor:**
  - o gráfico e as músicas ficam na mesma linha do tempo, com uma linha marcando o fim da aula;
  - **zoom com a roda do mouse** no ponto do cursor (Shift + roda anda para os lados; botões − / + / "Aula inteira");
  - cada música tem **"toca de … até …"**, e o botão **"✂ Cortar no fim da aula"** ajusta a última.
- **Ginásio:** toca as músicas da aula em sequência, cada uma no trecho escolhido, no relógio da aula. Os MP3 precisam estar no pendrive com o mesmo nome.

## Novo no 02/10b

- **Aula gravada no app:**
  - na TV, "Gravar" grava a câmera limpa e o roteiro da aula;
  - depois da aula, ela sobe sozinha para o servidor de teste;
  - o aluno da academia abre em **Loja → Aulas gravadas**, conecta a bike e faz a aula com o vídeo do professor e os números **dele**: bolas de RPM e watts, cartão próprio nas telas de cartões, o desafio só com ele, ranking junto com quem pedalou ao vivo.
- **Teste:** 5 gravações por academia, apagadas em 72 h. Nuvem de vídeo e compra ficam para quando contratar.
- **Saiu a mensalidade da academia** do Portal e do app (decisão do Mario).

## Novo no 02/10a

- **Desafio entre academias:**
  - Portal → **Desafio entre academias**: por período (vence a média por aluno) ou numa aula ao vivo no mesmo horário;
  - a outra academia entra com o código;
  - na TV, uma faixa com o placar das academias; no app, um cartão no início.
- **Gravar e transmitir:**
  - Ginásio → Configurar aula → **Câmera ao vivo** → "Gravar" ou "Gravar e transmitir";
  - grava em `C:\ProRider\Gravacoes`;
  - transmite no app ("📺 Assistir ao vivo") e no YouTube Live da academia (chave no Portal → **Gravar e transmitir**; precisa do ffmpeg, veja o passo 3b).
- **Lista de espera:**
  - aula lotada → o aluno entra na fila;
  - quem cancela ou não sobe na bike até 5 min depois do começo libera a bike para o 1º da fila, que recebe um e-mail;
  - lembrete por e-mail 1 h antes.
- **Strava/Garmin:** botão "Arquivo para Strava / Garmin" no resultado da aula no app.
- **Portal → Ocupação e sumidos:** mapa de ocupação por dia e horário e lista de quem parou de vir, com "Chamar de volta".

## Novo no 01/10f: RESERVA COM A BIKE

- **App:** lupinha → academia → grade → **Reservar** abre o mapa das bikes (15 no Clube). Só reserva depois de escolher; as reservadas por outros ficam em vermelho. A grade mostra "✓ Bike N · trocar".
- **TV, tela do QR:** quem reservou aparece na bike reservada, com nome e foto (cartão amarelo "reservou · aguardando"). Pedalando, o cartão fica **verde** com o nome, mesmo sem abrir o app.
- **Na hora de entrar:** a bike reservada aparece como "SUA RESERVA" para quem reservou e ocupada para os outros. Ao entrar, a reserva vira "presente".

## Novo no 01/10e (correção — publique este no lugar do 01/10d)

- O `style.css` do 01/10d saiu **cortado**: as telas "De onde vem a aula", "Configurar aula" e "Entrar na aula (QR)" ficavam sem visual. Restaurado.
- Gráficos do perfil proporcionais ao tempo (não ficam mais esticados).
- START na tela inicial funciona direto.
- Mais leve na configuração e na aula ao vivo.

## Novo no 01/10d

- **Tela de espera da TV (opção 2, aprovada):** logo original sempre no centro, um pouco maior. Com aula no dia, as **aulas de hoje passam rodando embaixo**; academia e data no canto de cima à esquerda, relógio à direita. Sem aula, só o logo no centro.

## Novo no 01/10c

- **Tela de espera da TV:** volta a ser a original (fundo quadriculado, raio, PRO/RIDER). A grade de hoje fica flutuando à direita, no mesmo fundo.
- **Logo original em todo lugar:** o arquivo `img/logo-prorider.png` (site) e `logo-prorider.png` (Ginásio) é o raio com PRO RIDER e "cycling performance". Trocar o arquivo muda o logo em todas as telas.

## Novo no 01/10a: CAMPEONATOS

- **Portal → Campeonatos:**
  - escolha **Tour de France** (camisa amarela), **Giro d'Italia** (rosa), **La Vuelta** (vermelha) ou **Mundial** (arco-íris do campeão);
  - marque as aulas da grade que valem como etapa (plano, montanha, sprint, contra-relógio ou **rainha**, que vale em dobro).
- **Pontos por etapa, pelo WPP:** 25, 20, 16, 13, 11, 10, 9, 8, 7, 6; do 11º em diante, 1 ponto. Quem falta fica com 0, e a classificação é refeita depois de cada etapa.
- **Camisas:**
  - líder, pontos (sprint), montanha e estreante (cadastro com até 90 dias);
  - no fim, ficam **gravadas na conta** de quem ganhou e aparecem no app e na TV de qualquer academia;
  - no Mundial, só a arco-íris, que fica com o campeão.
- **TV:** reconhece a etapa sozinha pelo horário e soma sprint e montanha bloco a bloco. No fim, mostra a classificação como 3ª tela, com a camisa ao lado do nome.
- **App:** cartão do campeonato no início e "Minhas camisas" no perfil.

**Também continua valendo (30/09e e 30/09f):**
- telas novas de preparar a aula;
- YouTube de fundo;
- contagem do Spotify;
- e-mails editáveis;
- login de professor em qualquer academia;
- câmera ao vivo em cartão próprio.

---

## 1. O que tem em cada pasta

| Pasta | O que é | Para onde vai |
|---|---|---|
| `1_SERVIDOR/server.js` | Servidor 01/10a (já contém os seus 26/09g e 26/09h) | Raiz do repositório `prorider-server` (Railway) |
| `2_SITE_pasta_public/` | Portal, site, totem, página pública e o app do aluno | Pasta `public/` do `prorider-server`, **com a mesma estrutura** |
| `3_GINASIO/ProRider_1_GINASIO_02-10c.zip` | Programa da TV (BUILD 02/10c) | Computador do Ginásio: `C:\ProRider\Executavel\app\` |
| `4_REGISTROS/` | `CHANGELOG.md` e `PENDENTES.md` | Raiz do `prorider-server` (substituir) |

Detalhe da pasta `2_SITE_pasta_public/`:

```
public/
├── index.html              entrada do site + Portal do super admin
├── academia.html           Portal da academia (gestor)
├── aluno.html              portal do aluno (navegador)
├── aluno/index.html        APP DO ALUNO (BUILD 01/10c)  ← atenção: fica na subpasta aluno/
├── brasoes.js              NOVO: desenho dos brasões (usado por várias páginas)
├── academia-publica.html   NOVO: página pública da academia
├── totem.html              NOVO: totem do tablet da porta
├── img/                    imagens (entrada do site + LOGO ORIGINAL)
│   ├── entrada-arte.jpg, entrada-logo.jpg, entrada-titulo.jpg, entrada-ciclista.jpg
│   ├── logo-prorider.png   NOVO 30/09e: logo original (Portal, e-mails, app, Construtor)
│   └── titulo-arte.png
└── jim.html, onboarding.html, studio.html   (iguais aos de hoje, só para a pasta ficar completa)
```

**Copie por cima e substitua os de mesmo nome.** Não apague outros arquivos que já existam em `public/`.

---

## 2. Antes de começar (2 minutos)

1. **Faça uma cópia de segurança** do que está no ar hoje: `server.js` e a pasta `public/` inteira, ou só anote o commit atual no GitHub. Se algo der errado, é só voltar.
2. **Se você mudou o `server.js` no GitHub depois do 26/09h**, me avise antes de substituir. Este arquivo tem o seu 26/09g (o `/ping` sem `db_url`) e o 26/09h (rotas de setup com `SETUP_KEY`). Mudanças posteriores precisam ser juntadas à mão.

---

## 3. Ordem de publicação

### Passo 1: servidor (primeiro, porque as páginas usam rotas novas)
1. Troque `server.js` na raiz do `prorider-server`.
2. Troque `CHANGELOG.md` e `PENDENTES.md` (pasta `4_REGISTROS`).
3. Commit e push. O Railway publica sozinho.
4. **Confira no log do Railway** (aba Deployments → View logs). Devem aparecer:
   - `Migração 29/09a (brasões, página pública, totem) OK`
   - `Migração 29/09c (localização) OK`
   - `Migração 01/10a (campeonatos) OK`
   - `Migração 02/10a (desafio entre academias) OK`, `Migração 02/10b (gravar e transmitir) OK` e `Migração 02/10c (lista de espera e lembretes) OK` (novos)
   - `Migração aulas_reservas OK`. Se vier antes um `Aviso: índice de bike única…`, não é erro: há reservas antigas repetidas na mesma bike. A checagem continua no servidor; me mande o aviso.
   - uns 15 segundos depois, linhas `geo: CODIGO → lat,lng`, uma para cada academia que já tem endereço cadastrado.

   Se aparecer `Migração ERRO`, **pare** e me mande o log.

### Passo 2: site, Portal e app (no mesmo commit do passo 1, se preferir)
1. Copie o conteúdo de `2_SITE_pasta_public/` para `public/`, **incluindo a pasta nova `img/`** e o arquivo `aluno/index.html`.
2. Commit e push.

### Passo 3: Ginásio (computador da TV)
1. Descompacte `3_GINASIO/ProRider_1_GINASIO_02-10c.zip` em `C:\ProRider\Executavel\app\`, substituindo os arquivos. Arquivos novos desde a 30/09b: `telas-pv.js` e `logo-prorider.png` (e o `brasoes.js` da 29/09a). **Os três precisam estar na pasta**; o `ginasio.html` carrega todos eles.
2. Rode `npm run dist`, como nas outras versões.
3. Abra o programa: a tela inicial mostra **BUILD 02/10b**.
3b. **Para o YouTube Live:**
   - baixe o ffmpeg para Windows (gratuito: "ffmpeg release essentials", em gyan.dev);
   - descompacte em `C:\ProRider\ffmpeg`, até existir `C:\ProRider\ffmpeg\bin\ffmpeg.exe`.

   Sem ele, gravar e transmitir no app funcionam; só o YouTube fica de fora.
3c. A primeira vez que gravar, o Windows pode pedir permissão de **câmera e microfone**: aceite.
4. **YouTube no executável:** se o Electron abre o `ginasio.html` como arquivo (`file://`), o YouTube pode recusar tocar (erro 153). A aula continua com o cenário. Para o YouTube funcionar, o Electron deve abrir `http://localhost:3000/ginasio` (o `servidor-local.js` já serve a pasta). Pelo `PRORIDER.bat` (Chrome) já funciona.

---

## 4. Variáveis de ambiente (Railway)

**Nenhuma variável nova é obrigatória.** Confira só se `PORTAL_URL` aponta para o endereço público do site: é de lá que os e-mails puxam o logo.

| Variável | Precisa? | Para quê |
|---|---|---|
| `SETUP_KEY` | Só se for usar as rotas de setup | Com 12 caracteres ou mais. Sem ela, `/admin/criar-admin`, `/admin/setup-promote`, `/setup/bootstrap` e `/setup/sessao-teste` respondem 404 (é o comportamento seguro). |
| `GEOCODER_EMAIL` | Opcional | Contato enviado ao serviço de mapa (OpenStreetMap). Padrão: contato@prorider.app. |

A busca de endereço no mapa usa o **OpenStreetMap (Nominatim)**, que é grátis e não tem chave. O servidor só precisa acessar `https://nominatim.openstreetmap.org`, e o Railway já acessa a internet normalmente.

---

## 5. Banco de dados

**Não precisa rodar nada à mão.** O servidor faz tudo sozinho ao iniciar, e é seguro rodar mais de uma vez:

- colunas novas em `licencas`: `pagina_cfg`, `totem_token`, `geo_fonte` e `geo_em`. As colunas `lat` e `lng` já existiam e agora são usadas;
- recalcula `users.level` pela escada nova de brasões, pelos pontos que cada aluno já tem. **Ninguém perde pontos.**

---

## 6. Como conferir que subiu certo (5 minutos)

| # | Onde | O que deve acontecer |
|---|---|---|
| 1 | Abrir a raiz do servidor no navegador do computador | A tela "RIDE WITH PURPOSE" aparece com os 6 contadores preenchidos |
| 2 | A mesma raiz no celular | Versão empilhada (logo, título, login, contadores) |
| 3 | `GET /public/stats` | JSON com `atletas`, `km`, `kcal`, `aulas`, `horas`, `wpp_total` |
| 4 | `GET /agenda/cidades?lat=-23.56&lng=-46.70` | Lista de academias com `dist_km`, em ordem de distância |
| 5 | Portal → entrar numa academia → **Página no site** | Cartões "Localização no app" e "Link e código para o site", com a prévia à direita |
| 6 | Portal → **Totem na porta** | Link e QR do totem |
| 7 | App (`/aluno`) → Agenda | Botão **"Perto de mim"** abaixo da busca |
| 7b | Portal → **Construtor de aulas** → Abrir o Construtor | Construtor novo com o visual do Portal; blocos cabem na tela; "Salvar na minha conta" funciona |
| 8 | Ginásio | BUILD 02/10b na tela inicial; com aula na grade de hoje, a tela de espera mostra os cartões grandes |
| 9 | Ginásio, na aula | LB+RB segurados 5 s escurecem a **TV inteira**; SELECT volta ao gráfico |
| 10 | Ginásio, na aula | Teste de FTP ou desafio: SELECT para e mostra o resultado; SELECT de novo volta ao gráfico. Sem nada rodando: SELECT pergunta "Encerrar aula?" |

| 11 | Ginásio → Minhas aulas | O QR aparece sozinho no cartão "Da minha conta"; ler com o app logado como professor (pode ser de outra academia) → as aulas dele aparecem |
| 12 | Ginásio → aula com playlist e YouTube | Configurar aula mostra o QR da playlist e a miniatura do vídeo; na largada, a contagem pede o play do Spotify e o YouTube entra no fundo, sem som. **Precisa de internet no computador da TV** |
| 13 | Portal → E-mails automáticos | Editar o texto muda a prévia; "Mandar este e-mail para mim" chega com "[TESTE]" e o logo original |
| 14 | App (professor) → Construtor | Abre o mesmo Construtor online; no celular em pé aparece "vire o celular de lado" |
| 15 | Portal → **Campeonatos** | Escolher Tour, Giro, Vuelta ou Mundial, o período e marcar aulas da grade como etapas → Salvar |
| 16 | Ginásio, na aula que é etapa | Na tela do QR aparece "🏁 Etapa N de M"; no fim: AULA CONCLUÍDA → RANKING → **classificação do campeonato** (camisas, fotos, setas) |
| 17 | App, no início | Cartão do campeonato com a posição, a camisa e a próxima etapa; no perfil, **Minhas camisas** |
| 18 | App → Agenda → academia → **Reservar** | Abre o mapa das bikes; o botão só libera depois de escolher; a grade mostra "✓ Bike N · trocar" |
| 19 | Ginásio → tela do QR da aula reservada | Nome e foto na bike reservada (amarelo); pedalando nela, verde |
| 20 | Portal → **Desafio entre academias** | Criar → aparece o código DA-XXXXXX; outra academia entra com ele → as duas no ranking |
| 21 | Ginásio → Câmera ao vivo → **Gravar e transmitir** | Na aula: selo "AO VIVO" no canto; no app, faixa verde com "📺 Assistir ao vivo"; no fim, arquivo em `C:\ProRider\Gravacoes` e na lista do Portal |
| 22 | App → aula lotada | Botão "Lotado · entrar na fila"; se alguém cancelar, o 1º da fila ganha a bike |
| 23 | Portal → **Ocupação e sumidos** | Mapa por dia e horário (enche a cada aula fechada na TV) e lista de sumidos |
| 24 | Ginásio → Câmera ao vivo → **Gravar** → dar uma aula | No fim, a gravação sobe sozinha; no app (aluno da academia): **Loja → Aulas gravadas** → conectar a bike → vídeo do professor com os números do aluno; no fim, ranking com quem pedalou ao vivo |
---

## 7. Teste do Mario: reserva e entrada pela lupinha

Depois de publicado, o Mario faz este roteiro no Clube:

1. **Localização:** pelo **celular, dentro do Clube**, abrir o Portal → Página no site → **"Estou na academia: usar este aparelho"** → permitir. O cartão fica verde: "✓ Aparece no Perto de mim".
2. **Grade:** Portal → Grade → confirmar que tem aula hoje; se não tiver, criar uma para daqui a uns 30 minutos.
3. **Reserva:** no app, Agenda → **Perto de mim** → Clube → **Reservar** a aula de hoje → **escolher a bike** (1 a 15) → Reservar. Ela aparece em "Minhas reservas" com o número da bike.
4. **Abrir a aula:** no Ginásio, abrir a aula (pré-aula, tela do QR). **O nome já aparece na bike reservada, em amarelo.** Subindo na bike e pedalando, fica verde.
5. **Entrar pela lupinha:** em até 15 segundos, o Clube aparece no app com a etiqueta verde "AULA ABRINDO · N bikes livres". Tocar no Clube → faixa verde "aula ao vivo" → a bike reservada vem marcada "SUA RESERVA" → tocar nela. **O nome aparece na TV.**

Se algum passo falhar, anote em qual e mande o print para o Mario me repassar.

---

## 8. Se precisar voltar atrás

- **Servidor e site:** volte ao commit anterior no GitHub, e o Railway republica. As colunas novas do banco não atrapalham a versão antiga, porque só são lidas pelo código novo.
- **Ginásio:** reinstale o executável anterior.

---

## 9. Segurança (lembretes que continuam valendo)

- Trocar a senha do Postgres no Railway, se ainda não trocou.
- Trocar a senha do super admin, se ainda for a antiga.
- Trocar a senha de `gestor001@prorider.com` ou desativar essa conta: a senha dela está escrita na migração antiga.
- **Nunca** colocar `DATABASE_URL` ou senhas em arquivos, commits ou mensagens.

---

Detalhes técnicos de cada mudança (o que mudou, por quê, como confirmar, cuidados) estão no `CHANGELOG.md`, nas entradas **01/10a**, **30/09f**, **30/09e**, **30/09d**, **30/09c**, **30/09b**, **30/09a**, **29/09c** e **29/09b**.
