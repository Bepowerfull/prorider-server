Oi! Segue o **pacote completo 02/10c**. Ele substitui o 02/10b, e o passo a passo está no `00_LEIA-PRIMEIRO.md`.

**O que mudou desde o 02/10b:**
- **Construtor (`studio.html`):** linha do tempo única para o gráfico e as músicas, zoom com a roda do mouse e o trecho de cada música ("toca de … até …").
- **Ginásio (BUILD 02/10c):** toca as músicas da aula em sequência, cada uma no seu trecho. Só o `telas-pv.js`, o `script.js` (BUILD) e o `LEIA-ME.txt` mudaram.
- `server.js` e `servidor-local.js` **não mudaram**.

**Se o 02/10b ainda não subiu:** suba este no lugar dele, porque ele já contém tudo.

O pacote passou pela conferência automática (`conferir_pacote.py`).

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` em arquivos ou mensagens;
- a chave do YouTube só o gestor cola no Portal.

Obrigado!
