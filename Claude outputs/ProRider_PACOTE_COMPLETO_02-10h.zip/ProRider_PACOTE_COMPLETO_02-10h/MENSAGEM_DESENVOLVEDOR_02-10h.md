Oi! Segue o **pacote 02/10h**: a página de pagamento do financeiro. Ele substitui o 02/10g.

**O que subir:**
- `server.js`;
- no site: `academia.html` e o arquivo **novo** `financeiro.html` (na mesma pasta);
- o Ginásio não mudou (só o número da versão; trocar é opcional).

**O que mudou:**
- A regra do Mario: a página de pagamento é **só do responsável financeiro**, ou seja, o login cujo e-mail é o `financeiro_email` da licença. Gestor e coordenador ficam de fora (menu e rota). Super admin em modo suporte só lê.
- O financeiro entra pela mesma tela do Portal e cai em `financeiro.html`. Quem não tem conta cria ali, ou pelo app.
- Rotas novas: `GET /academia/financeiro` e `POST /academia/financeiro/pagar`. Na 1ª vez, a rota cria o cliente e a assinatura no Asaas (cartão, valor da licença, CPF/CNPJ informado) e devolve o `invoiceUrl`. O cartão é digitado na página do Asaas.
- A rota antiga `PUT /academia/financeiro/cartao` (últimos 4 dígitos à mão) saiu.
- Trocar o `financeiro_email` no admin passa o papel "financeiro" para o novo cadastro e devolve o antigo a aluno.
- Colunas novas: `licencas.asaas_customer` e `asaas_sub`. A sua rota `/admin/asaas/assinatura` também grava nelas.
- As suas rotas e a conferência do token do webhook (02/10g) continuam iguais.

**Antes da 1ª cobrança real, por favor teste no sandbox do Asaas:**
1. Em um ambiente de teste, ponha `ASAAS_URL=https://api-sandbox.asaas.com/v3` e a chave do sandbox em `ASAAS_API_KEY`.
2. Cadastre um e-mail de financeiro numa licença de teste, entre com ele, clique em "Cadastrar cartão e pagar" e pague com um cartão de teste.
3. Confirme duas coisas: que o webhook deixa a licença "em dia" e que a assinatura guarda o cartão para o mês seguinte.
Em produção não use `ASAAS_URL`: sem ela o servidor usa `api.asaas.com`.

O pacote passou pela conferência automática (`conferir_pacote.py`).

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` nem chaves (Asaas incluída) em arquivos ou mensagens.

Obrigado!
