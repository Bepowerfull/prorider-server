# ProRider · 29/09b · entrada do site, totem, página da academia, brasões, faixa verde e aulas na TV

| Arquivo | Versão | Vai para |
|---|---|---|
| `server.js` | 29/09b (já inclui o 26/09g e o 26/09h) | Railway — **publicar primeiro** |
| `ProRider_PORTAL_29-09b.zip` | 29/09b | Railway `public/` (ver o LEIA-ME dentro; **criar `public/img/`**) |
| `aluno.html` | BUILD 29/09a | Railway `public/aluno/index.html` |
| `ProRider_1_GINASIO_29-09b.zip` | BUILD 29/09b | executável: `C:\ProRider\Executavel\app\` + `npm run dist` (tem arquivo novo: `brasoes.js`) |
| `CHANGELOG.md` / `PENDENTES.md` | até 29/09b | raiz do `prorider-server` |

**Este pacote substitui o 29/09a (que não foi publicado).** Mudou: a entrada do site agora é idêntica à arte do marketing, e a escada de brasões é nova.

**Sobre o server.js:** conferi que ele contém o seu 26/09g (o `/ping` sem `db_url`) e o 26/09h. Se o GitHub tiver alguma mudança sua depois disso, me avise antes de substituir.

**Migração automática** (o log mostra `Migração 29/09a (brasões, página pública, totem) OK`):
- colunas novas `licencas.pagina_cfg` e `licencas.totem_token`;
- recálculo de `users.level` na escada de brasões nova.

## Como confirmar
1. A raiz do site mostra "RIDE WITH PURPOSE" com os contadores. `GET /public/stats` responde JSON.
2. Com o Ginásio 29/09a na pré-aula, o app mostra a faixa verde em Agenda → buscar academia → Clube.
3. No Portal (entrando no Clube), "Totem na porta" gera o link. Abra no tablet e teste "Pedalar sem conta": o nome aparece na bike escolhida na TV.
4. "Página no site" mostra a prévia da página pública.

## Rotas novas
- `GET /public/stats`
- `GET /public/academia/:codigo`
- `GET/PUT /gestor/pagina`
- `GET /gestor/totem`
- `GET /totem/:t/info`
- `POST /totem/:t/identificar`, `/cadastro`, `/foto`, `/reservar` e `/entrar`

Detalhes no CHANGELOG.
