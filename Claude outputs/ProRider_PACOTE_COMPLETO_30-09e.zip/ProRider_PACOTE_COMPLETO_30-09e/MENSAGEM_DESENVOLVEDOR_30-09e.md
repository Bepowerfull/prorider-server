Oi! Segue o **pacote completo 30/09e** (substitui todos os anteriores). O passo a passo está no `00_LEIA-PRIMEIRO.md`.

**Resumo do que muda**
- **Servidor** (`server.js`):
  - e-mails editáveis (textos em `licencas.emails_cfg.textos`, sem migração) e rota nova `POST /gestor/emails/previa`;
  - o `POST /professor/parear` aceita professor/coordenador/gestor de **qualquer** academia (aluno continua 403).
- **Site** (`public/`):
  - página E-mails automáticos no Portal;
  - Construtor também no celular;
  - logo original em `img/logo-prorider.png` (**imagem nova**);
  - `aluno/index.html` com o Construtor novo.
- **Ginásio** (BUILD 30/09e):
  - telas de preparar a aula novas;
  - YouTube de fundo;
  - contagem com o play do Spotify;
  - tela final nova;
  - correção do desafio do Construtor.
  - **Dois arquivos novos no zip: `telas-pv.js` e `logo-prorider.png`**, que precisam ir para `C:\ProRider\Executavel\app\` antes do `npm run dist`.

**Ordem:** servidor + site (mesmo commit) → Ginásio.

**Atenção no Ginásio:** o YouTube precisa de internet e de a página ter origem http. Pelo `PRORIDER.bat` já é assim (`http://localhost:3000/ginasio`). Se o Electron abrir por `file://`, o YouTube pode não tocar (a aula segue com o cenário). Nesse caso, dá para fazer o Electron carregar `http://localhost:3000/ginasio`.

**Conferir depois de publicar:** itens 11 a 14 da tabela do `00_LEIA-PRIMEIRO.md`.

**Segurança, os mesmos lembretes de sempre:**
- trocar a senha do Postgres;
- trocar a do super admin, se ainda for a antiga;
- trocar a senha de `gestor001@prorider.com` ou desativar a conta;
- nunca pôr `DATABASE_URL` em arquivo ou mensagem.

Qualquer erro no log (`Migração ERRO`) ou no console da TV, manda print. Obrigado!
