# ProRider · 26/09e · Portal novo, servidor, Ginásio e app

| Arquivo | Versão | Vai para |
|---|---|---|
| `server.js` | 26/09e | Railway (commit novo) — **publicar primeiro** |
| `ProRider_PORTAL_26-09e.zip` | 26/09e | Railway: pasta `public/` (mudaram `index.html` e `academia.html`) |
| `aluno.html` | BUILD 26/09e | Railway: `public/aluno/index.html` |
| `ProRider_1_GINASIO_26-09e.zip` | BUILD 26/09e | executável do Ginásio. Mesmo processo: copiar para `C:\ProRider\Executavel\app\`, `npm run dist` e copiar o `.exe`. |
| `CHANGELOG.md` | até 26/09e | raiz do `prorider-server`, no mesmo commit |

## Precisa de você: e-mail
Sem configuração, **nenhum e-mail sai**. O Portal avisa e mostra a senha provisória na tela. Escolha **uma** das opções no Railway (Variables):

- **Resend (recomendado, sem instalar nada):** `RESEND_API_KEY=re_...` e `EMAIL_FROM="ProRider <nao-responda@SEU-DOMINIO>"`. O domínio precisa estar verificado no resend.com.
- **SMTP (ex.: Gmail com senha de app):** `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `EMAIL_FROM`. Também precisa `npm i nodemailer` no `package.json`.
- Opcional: `PORTAL_URL` (link dos botões; padrão: o próprio servidor).

**Teste:** no Portal, abra E-mails automáticos e clique em "Mandar um teste para mim".

## Servidor
- **Histórico do Portal zerado — corrigido.** O app gravava a aula só em `aulas_completadas`, mas o Portal lê `aula_historico`. Agora `/aula/complete` grava nas duas, e a migração copia as aulas antigas (sem duplicar).
- **Aluno entra na academia sozinho:** o Ginásio manda o token da licença no `criar_sala`. Quem entra na sala sem academia passa a ser dela.
- **Níveis de acesso:** coordenador e financeiro entram no Portal, cada um com o seu limite.
- **Rotas novas:**
  - `/gestor/config/ranking`
  - `/gestor/emails` e `/gestor/emails/teste`
  - `/gestor/equipe` e `/gestor/equipe/:id/papel`
  - `/user/senha`
- **Nova licença:** cria também o login do gestor.
- **Versão do Ginásio:** o Ginásio informa a versão pelo cabeçalho `X-PR-Build`.
- **Migração automática:**
  - colunas novas: `ranking_cfg`, `emails_cfg`, `build`, `nascimento`, `foto_url`;
  - tabela nova: `email_log`.

Detalhes no `CHANGELOG.md`.

**Como confirmar:** o log do Railway mostra `Migração portal 26/09e OK`.

## Portal
- O login do `index.html` agora aceita `super_admin`. Antes só `admin` entrava, e era por isso que o Mario não achava onde criar licença.
- Menu lateral por papel.
- Barra "Voltar ao meu painel" no modo suporte.
- Nova licença com endereço e gestor.
- Coluna com a versão do Ginásio de cada TV.
- Alunos com lupa.
- Ranking na TV, Equipe, E-mails e Meu perfil.

## Ginásio
- A tela de Ranking (B) usa os campos e a ordem escolhidos no Portal. Sem configuração, fica como era.
- Informa a versão ao servidor.

**Como confirmar:** `BUILD 26/09e` na tela inicial.

## App
- `/aluno#construtor` abre direto o Construtor. É o botão "Criar aula" do Portal.
