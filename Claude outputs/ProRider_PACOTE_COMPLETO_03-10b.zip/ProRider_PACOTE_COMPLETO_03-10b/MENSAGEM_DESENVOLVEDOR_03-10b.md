Oi! Segue o **pacote 03/10b** (revisão completa do pagamento). Ele substitui o 02/10m e o 03/10a.

**Na dúvida, suba tudo deste pacote:** `server.js`, a pasta `2_SITE_pasta_public` inteira e o Ginásio inteiro.

**3 coisas que dependem de você no Railway / no código de produção:**

1. **Apagar o seed que reseta senha.** O `server.js` de produção tem um trecho (mais ou menos linhas 713–733) que, a cada boot, volta a senha das contas financeiro das Demo para `12345678` e corrige o e-mail "provider.demo01". **Não suba esse trecho de novo** (o repositório é público e ele derruba a senha que a pessoa criou). Suba o `server.js` deste pacote como está.
2. **E-mail com a senha.** Hoje a conta nova não recebe o e-mail porque o servidor está sem provedor (ou com o Resend sem domínio). Precisa:
   - `RESEND_API_KEY` no Railway;
   - domínio **prorider.com.br verificado** no Resend (registros DNS que o Resend mostra);
   - `EMAIL_FROM` = `ProRider <acesso@prorider.com.br>` (ou outro endereço do domínio).
   Sem isso o Resend só entrega para o dono da conta. A tela do admin agora mostra esse motivo.
3. **Manter `ASAAS_WEBHOOK_TOKEN`** (igual ao do painel do Asaas). No painel do Asaas, o webhook precisa estar com os eventos de **cobrança** ligados (inclusive estorno, "recebimento em dinheiro desfeito" e cartão recusado).

**O que mudou no `server.js`:**
- Migração automática: `pagamentos` ganha `origem`, `asaas_id` (índice único), `venc_ref`, `cobre_ate`; `licencas` ganha `asaas_aviso`; licenças `bloqueada` voltam a `ativa`.
- `licencas.vencimento` passa a ser o **próximo vencimento**; `pagamento_ok_ate` = pago até. Funções novas: `proxVenc`, `finSituacao`, `pgRecalc`, `asaasSyncLic`.
- `POST /academia/financeiro/pagar`: `nextDueDate` = próximo vencimento (antes: hoje).
- Webhook do Asaas reescrito (livro-caixa, sem duplicar, desfaz estorno/dinheiro desfeito/chargeback, acha a licença pela assinatura ou cliente).
- `POST /admin/pagamentos/:lic` só aceita recebido por fora (pix/transferencia/dinheiro/boleto/cortesia) com `confirmo:true`. Novas: `DELETE /admin/pagamentos/:lic/:id` (desfazer manual), `POST /admin/pagamentos/:lic/sync-asaas`, `POST /admin/licencas/:id/reenviar-acesso`.
- `GET /admin/pagamentos/:lic` não grava mais nada (antes punha `status='bloqueada'` e travava a TV).
- `PUT /admin/licencas/:id` e `PATCH .../financeiro` acertam a fatura/assinatura do Asaas quando muda vencimento ou valor; `DELETE /admin/licencas/:id` cancela a assinatura.
- `/display/ativar` também recusa licença suspensa (mesma regra do `/display/renovar`).
- `/user/me` devolve `financeiro`.
- **03/10b:** migração única `venc_migrado` (o "dia de vencimento" antigo vira a data do próximo vencimento nas licenças que nunca pagaram); o acerto do Asaas move todas as faturas em aberto (o Asaas gera os meses seguintes adiantado); `GET /academia/financeiro` acerta as datas no Asaas se não baterem.
- **Site 03/10b:** `index.html` e `aluno.html` mandam o e-mail do financeiro para `financeiro.html` (antes só o `academia.html`).

Testado com o Asaas simulado (39 verificações) e com as telas no navegador. O pacote passou pela conferência automática (`conferir_pacote.py`).

Obrigado!
