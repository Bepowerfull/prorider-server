Oi! Obrigado pelo retorno. Segue o **pacote 02/10g**.

**O que mudou desde o 02/10f (commit 2c33a79): só o `server.js`.**
- As suas duas rotas do Asaas (`/webhook/asaas` e `/admin/asaas/assinatura`) agora fazem parte do `server.js` do pacote, no mesmo lugar (antes do `server.listen`). Os próximos pacotes não as apagam mais.
- O webhook confere o cabeçalho `asaas-access-token` contra a variável **`ASAAS_WEBHOOK_TOKEN`**, como você sugeriu. Sem a variável, ou com token errado, ele responde 401 e registra no log.
- Erro interno do webhook não devolve mais a mensagem do erro.

**No mesmo deploy, por favor:**
1. Gere o token no painel do Asaas (configuração do webhook).
2. Crie `ASAAS_WEBHOOK_TOKEN` no Railway com esse mesmo valor.
3. Suba o `server.js`. Se a variável faltar, os avisos de pagamento são recusados até ela entrar.
4. Confira no painel do Asaas se a fila de webhooks não ficou pausada.

O site e o Ginásio não mudaram (o Ginásio só mudou o número da versão; trocar é opcional).

**Daqui para frente:** se mudar algo no servidor fora dos pacotes, me mande o arquivo, para entrar no próximo pacote.

O pacote passou pela conferência automática (`conferir_pacote.py`).

**Segurança, os mesmos lembretes:**
- trocar a senha do Postgres;
- trocar a senha do super admin, se ainda for a antiga;
- trocar a senha ou desativar `gestor001@prorider.com`;
- nunca pôr `DATABASE_URL` nem chaves (Asaas incluída) em arquivos ou mensagens;
- a chave do YouTube só o gestor cola no Portal.

Obrigado!
